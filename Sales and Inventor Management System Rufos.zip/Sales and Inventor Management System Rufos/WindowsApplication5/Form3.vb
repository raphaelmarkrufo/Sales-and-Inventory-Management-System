﻿Imports Guna.UI2.WinForms
Imports System.IO
Imports System.Data.SqlClient
Imports System.Windows.Forms.DataVisualization.Charting
Imports MessagingToolkit.QRCode.Codec
Imports MessagingToolkit.Barcode
Imports System.Text.RegularExpressions
Public Class Form3
    Private qrImage As Bitmap = Nothing
    Private barImage As Image = Nothing
    Private showingQR As Boolean = True
    Private Class CartTag
        Public Property CartID As Integer
        Public Property Quantity As Integer
        Public Property LblNum As Label
    End Class

    Private Sub GenerateCodes()
        Dim productName As String = txtProdName.Text.Trim()

        ' --- Skip generation if no product name ---
        If String.IsNullOrEmpty(productName) Then
            qrImage = Nothing
            barImage = Nothing
            picQRBAR.Image = Nothing
            btnQrBar.Enabled = False
            btnQrBar.Text = "No code"
            Return
        End If

        ' --- Generate QR Code ---
        Try
            Dim qrEnc As New MessagingToolkit.QRCode.Codec.QRCodeEncoder()
            qrImage = qrEnc.Encode(productName)
        Catch ex As Exception
            MessageBox.Show("QR code generation failed: " & ex.Message)
            qrImage = Nothing
        End Try

        ' --- Generate Barcode using only valid characters ---
        Dim barcodeText As String = Regex.Replace(productName.ToUpper(), "[^A-Z0-9 \-./$%+]", "")

        If Not String.IsNullOrEmpty(barcodeText) Then
            Try
                Dim barEnc As New MessagingToolkit.Barcode.BarcodeEncoder()
                barEnc.IncludeLabel = True
                barEnc.LabelPosition = MessagingToolkit.Barcode.LabelPositions.BottomCenter
                barEnc.Width = 300
                barEnc.Height = 80
                barImage = barEnc.Encode(MessagingToolkit.Barcode.BarcodeFormat.Code128, barcodeText)
            Catch ex As Exception
                ' Fallback to Code39
                Try
                    Dim barEnc2 As New MessagingToolkit.Barcode.BarcodeEncoder()
                    barEnc2.IncludeLabel = True
                    barEnc2.LabelPosition = MessagingToolkit.Barcode.LabelPositions.BottomCenter
                    barEnc2.Width = 300
                    barEnc2.Height = 80
                    barImage = barEnc2.Encode(MessagingToolkit.Barcode.BarcodeFormat.Code39, barcodeText)
                Catch ex2 As Exception
                    barImage = Nothing
                End Try
            End Try
        Else
            barImage = Nothing
        End If

        ' --- Display default code ---
        If qrImage IsNot Nothing Then
            picQRBAR.Image = qrImage
            showingQR = True
        ElseIf barImage IsNot Nothing Then
            picQRBAR.Image = barImage
            showingQR = False
        Else
            picQRBAR.Image = Nothing
        End If

        ' --- Configure flip button ---
        If qrImage IsNot Nothing AndAlso barImage IsNot Nothing Then
            btnQrBar.Enabled = True
            btnQrBar.Text = "Show Barcode"
        ElseIf barImage IsNot Nothing Then
            btnQrBar.Enabled = True
            btnQrBar.Text = "Show Barcode"
        ElseIf qrImage IsNot Nothing Then
            btnQrBar.Enabled = False
            btnQrBar.Text = "Barcode not available"
        Else
            btnQrBar.Enabled = False
            btnQrBar.Text = "No code"
        End If

        ' --- Ensure PictureBox displays correctly ---
        picQRBAR.SizeMode = PictureBoxSizeMode.Zoom
    End Sub


    Private Sub btnQrBar_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnQrBar.Click
        If qrImage Is Nothing AndAlso barImage Is Nothing Then Return

        If showingQR Then
            If barImage IsNot Nothing Then
                picQRBAR.Image = barImage
                showingQR = False
                btnQrBar.Text = "Show QR"
            End If
        Else
            If qrImage IsNot Nothing Then
                picQRBAR.Image = qrImage
                showingQR = True
                btnQrBar.Text = "Show Barcode"
            End If
        End If
    End Sub


    ' Example: When viewing stock, auto-generate QR & Barcode
    Private Sub btnViewStock_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnViewStock.Click
        GenerateCodes()
    End Sub
    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Public Class VScrollOnlyTableLayoutPanel
        Inherits TableLayoutPanel

        Protected Overrides ReadOnly Property CreateParams() As CreateParams
            Get
                Dim cp As CreateParams = MyBase.CreateParams
                cp.Style = cp.Style And Not &H100000       ' WS_HSCROLL
                Return cp
            End Get
        End Property
    End Class

    Private Sub LoadChart()
        Chart1.Series.Clear()
        Chart1.ChartAreas.Clear()
        Chart1.ChartAreas.Add("ChartArea1")

        Dim series As New Series("Stock")
        series.ChartType = SeriesChartType.Column
        Chart1.Series.Add(series)

        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"

        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "SELECT ProductName, Stock FROM Uniqlo"
            Using cmd As New SqlCommand(sql, conn)
                Using rdr As SqlDataReader = cmd.ExecuteReader()
                    While rdr.Read()
                        Dim name As String = rdr("ProductName").ToString()
                        Dim stock As Integer = Convert.ToInt32(rdr("Stock"))

                        ' Add data point
                        series.Points.AddXY(name, stock)
                    End While
                End Using
            End Using
        End Using

        ' Optional: format chart
        Chart1.ChartAreas(0).AxisX.Interval = 1
        Chart1.ChartAreas(0).AxisX.LabelStyle.Angle = -45   ' rotate labels if long
        Chart1.ChartAreas(0).AxisX.MajorGrid.Enabled = False
        Chart1.ChartAreas(0).AxisY.MajorGrid.LineColor = Color.LightGray
    End Sub

    Private Sub LoadProducts()
        Try
            Dim tbl As TableLayoutPanel = TableLayoutPanel1  ' inside TabPage2

            ' Reset TableLayoutPanel
            tbl.Controls.Clear()
            tbl.ColumnCount = 3
            tbl.RowCount = 0
            tbl.AutoScroll = True ' Enable scrolling
            tbl.AutoSize = True   ' Allow automatic resizing
            tbl.AutoSizeMode = AutoSizeMode.GrowAndShrink

            ' Equal column widths
            tbl.ColumnStyles.Clear()
            For i As Integer = 1 To 3
                tbl.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 33.33F))
            Next

            Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
            Using conn As New SqlConnection(connStr)
                conn.Open()

                Dim sql As String = "SELECT ProductID, ProductName, Price, Colors, Stock, Categories, Sizes, ImagePath FROM Uniqlo"
                Using cmd As New SqlCommand(sql, conn)
                    Using rdr As SqlDataReader = cmd.ExecuteReader()
                        Dim colIndex As Integer = 0
                        Dim rowIndex As Integer = 0

                        While rdr.Read()
                            ' Panel
                            Dim panel As New Panel With {
                                .Size = New Size(210, 270),
                                .BackColor = Color.White,
                                .BorderStyle = BorderStyle.FixedSingle,
                            .Margin = New Padding(10)
                            }

                            ' PictureBox
                            Dim pic As New PictureBox With {
                                .Size = New Size(115, 125),
                                .Location = New Point(23, 13),
                                .SizeMode = PictureBoxSizeMode.StretchImage
                            }
                            If Not IsDBNull(rdr("ImagePath")) AndAlso IO.File.Exists(rdr("ImagePath").ToString()) Then
                                pic.Image = Image.FromFile(rdr("ImagePath").ToString())
                            End If
                            panel.Controls.Add(pic)

                            ' Label
                            Dim prodName As String = rdr("ProductName").ToString()
                            If prodName.Length > 15 Then prodName = prodName.Substring(0, 15) & "..."
                            Dim lbl As New Label With {
                                .Size = New Size(146, 37),
                                .Location = New Point(22, 146),
                                .Font = New Font("Montserrat", 8, FontStyle.Regular),
                                .ForeColor = Color.Black,
                                .Text = prodName
                            }
                            panel.Controls.Add(lbl)


                            ' Label - Price
                            Dim price As Decimal = Convert.ToDecimal(rdr("Price"))
                            Dim lblPrice As New Label With {
                                .Size = New Size(146, 20),
                                .Location = New Point(22, 187),
                                .Font = New Font("Montserrat", 8, FontStyle.Regular),
                                .ForeColor = Color.Black,
                                .Text = "Price: " & price.ToString("N2")
                            }
                            panel.Controls.Add(lblPrice)

                            Dim selectedId As Integer = CInt(rdr("ProductID"))
                            ' Button
                            Dim btn As New Button With {
                                 .Name = "btnViewStock_" & selectedId,
                                .Size = New Size(105, 33),
                                .Location = New Point(89, 217),
                                .ForeColor = Color.Black,
                                .FlatStyle = FlatStyle.Flat,
                            .Text = "View Stock",
                            .Tag = selectedId
                            }
                            btn.FlatAppearance.BorderColor = Color.Red
                            btn.FlatAppearance.BorderSize = 1
                            btn.FlatAppearance.MouseDownBackColor = btn.BackColor
                            btn.FlatAppearance.MouseOverBackColor = btn.BackColor
                            panel.Controls.Add(btn)

                            AddHandler btn.Click,
      Sub(sender As Object, e As EventArgs)
          Dim id As Integer = CInt(DirectCast(sender, Button).Tag)

          ' Load product info into Form3 fields
          LoadProductInfo(id)

          ' Switch to Edit mode
          lblTitle.Text = "Edit Stock"
          btnAddProd.Text = "Edit Stock"
          btnAddProd.Tag = id

          ' Show delete button in edit mode
          btnDelete.Visible = True

          ' Go to TabPage3 (edit page)
          TabControl1.SelectedTab = TabPage3
      End Sub



                            ' Add panel to TableLayoutPanel
                            If tbl.RowCount <= rowIndex Then
                                tbl.RowCount += 1
                                tbl.RowStyles.Add(New RowStyle(SizeType.AutoSize))
                            End If

                            tbl.Controls.Add(panel, colIndex, rowIndex)


                            ' Update column and row index
                            colIndex += 1
                            If colIndex >= 3 Then
                                colIndex = 0
                                rowIndex += 1
                            End If
                        End While
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
        ' Check if TabPage1 is active
        If TabControl1.SelectedTab Is TabPage2 Then
            LoadProducts()
        End If

    End Sub

    Private Sub LoadProductInfo(ByVal productId As Integer)
        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"

        Using conn As New SqlConnection(connStr)
            conn.Open()

            Dim sql As String = "SELECT ProductName, Colors, Stock, Categories, Sizes, ImagePath, Price FROM Uniqlo WHERE ProductID=@id"


            Using cmd As New SqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@id", productId)

                Using rdr As SqlDataReader = cmd.ExecuteReader()
                    If rdr.Read() Then
                        ' --- Fill text fields ---
                        txtProdName.Text = rdr("ProductName").ToString()
                        txtColor.Text = rdr("Colors").ToString()
                        txtStock.Text = rdr("Stock").ToString()

                        ' Correct way to assign Price to txtPrice
                        txtPrice.Text = Convert.ToDecimal(rdr("Price")).ToString("F2")


                        ' --- Sizes ---
                        Dim sizes As String = rdr("Sizes").ToString().ToLower()
                        chkS.Checked = sizes.Contains("s")
                        chkM.Checked = sizes.Contains("m")
                        chkL.Checked = sizes.Contains("l")
                        chkXL.Checked = sizes.Contains("xl")
                        chkXXL.Checked = sizes.Contains("xxl")
                        chkXXXL.Checked = sizes.Contains("xxxl")

                        ' --- Categories ---
                        Dim cat As String = rdr("Categories").ToString().ToLower()
                        ChkHoodie.Checked = cat.Contains("hoodie")
                        ChkTshirt.Checked = cat.Contains("tshirt")
                        ChkSweather.Checked = cat.Contains("sweather")
                        ChkPants.Checked = cat.Contains("pants")
                        ChkDress.Checked = cat.Contains("dress")

                        ' --- Image ---
                        If Not IsDBNull(rdr("ImagePath")) AndAlso File.Exists(rdr("ImagePath").ToString()) Then
                            picProd.Image = Image.FromFile(rdr("ImagePath").ToString())
                        Else
                            picProd.Image = Nothing
                        End If

                        ' --- Buttons & tags ---
                        btnAddProd.Text = "Edit Stock"
                        lblTitle.Text = "Edit Stock"
                        btnAddProd.Tag = productId
                        btnDelete.Tag = productId
                    End If
                End Using
            End Using
        End Using

        ' ✅ Show Delete button only in Edit Stock mode
        btnDelete.Visible = True

        ' ✅ Switch tab
        TabControl1.SelectedTab = TabPage3

        ' ✅ Generate QR + Barcode automatically
        GenerateCodes()
    End Sub

Private Sub LoadCheckoutItems()
        TableLayoutPanel3.SuspendLayout()

        ' Reset TableLayoutPanel
        TableLayoutPanel3.Controls.Clear()
        TableLayoutPanel3.RowStyles.Clear()
        TableLayoutPanel3.ColumnStyles.Clear()

        TableLayoutPanel3.ColumnCount = 1
        TableLayoutPanel3.RowCount = 0
        TableLayoutPanel3.Padding = New Padding(0)
        TableLayoutPanel3.CellBorderStyle = TableLayoutPanelCellBorderStyle.None
        TableLayoutPanel3.AutoScroll = True
        TableLayoutPanel3.GrowStyle = TableLayoutPanelGrowStyle.AddRows

        ' Make column stretch full width
        TableLayoutPanel3.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100))

        TableLayoutPanel3.ResumeLayout()

        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "SELECT CartID, ProductID, ProductName, Price, Quantity, ImagePath FROM Uniqlo_Cart"

            Using cmd As New SqlCommand(sql, conn)
                Using rdr As SqlDataReader = cmd.ExecuteReader()
                    While rdr.Read()
                        Dim pnl As New Panel()
                        pnl.AutoSize = True
                        pnl.BorderStyle = BorderStyle.FixedSingle
                        pnl.Margin = New Padding(0)
                        pnl.Dock = DockStyle.Top

                        ' PictureBox
                        Dim picSales As New PictureBox() With {
                            .Size = New Size(59, 56),
                            .Location = New Point(9, 24),
                            .SizeMode = PictureBoxSizeMode.StretchImage
                        }
                        If Not IsDBNull(rdr("ImagePath")) AndAlso File.Exists(rdr("ImagePath").ToString()) Then
                            picSales.Image = Image.FromFile(rdr("ImagePath").ToString())
                        End If
                        pnl.Controls.Add(picSales)

                        ' Name label
                        Dim lblSName As New Label() With {
                            .Location = New Point(78, 15),
                            .Font = New Font("Montserrat", 9),
                            .ForeColor = Color.Black,
                            .AutoSize = True,
                            .Text = rdr("ProductName").ToString()
                        }
                        pnl.Controls.Add(lblSName)

                        ' Price label
                        Dim lblSPrice As New Label() With {
                            .Location = New Point(79, 35),
                            .Font = New Font("Montserrat", 7),
                            .ForeColor = Color.Black,
                            .AutoSize = True,
                            .Text = Convert.ToDecimal(rdr("Price")).ToString("F2")
                        }
                        pnl.Controls.Add(lblSPrice)

                        ' Quantity label
                        Dim lblNum As New Label() With {
                            .Location = New Point(111, 69),
                            .Font = New Font("Montserrat", 10),
                            .ForeColor = Color.Black,
                            .AutoSize = True,
                            .Text = rdr("Quantity").ToString()
                        }
                        pnl.Controls.Add(lblNum)

                        ' Minus button
                        Dim lblMinus As New Label() With {
                            .Location = New Point(77, 62),
                            .Font = New Font("Montserrat", 14),
                            .ForeColor = Color.Black,
                            .Text = "-",
                            .Cursor = Cursors.Hand
                        }
                        AddHandler lblMinus.Click, AddressOf CheckoutMinus_Click
                        pnl.Controls.Add(lblMinus)

                        ' Plus button
                        Dim lblPlus As New Label() With {
                            .Location = New Point(147, 62),
                            .Font = New Font("Montserrat", 14),
                            .ForeColor = Color.Black,
                            .Text = "+",
                            .Cursor = Cursors.Hand
                        }
                        AddHandler lblPlus.Click, AddressOf CheckoutPlus_Click

                        pnl.Controls.Add(lblPlus)
                        lblPlus.BringToFront()  ' ✅ ensure label is on top


                        ' Remove button
                        Dim lblRemove As New Label() With {
                            .Location = New Point(164, 8),
                            .Font = New Font("Montserrat", 14),
                            .ForeColor = Color.Red,
                            .Text = "X",
                            .Cursor = Cursors.Hand
                        }
                        AddHandler lblRemove.Click, AddressOf CheckoutRemove_Click
                        pnl.Controls.Add(lblRemove)

                        ' Store CartID, Quantity, lblNum in Tag
                        pnl.Tag = New CartTag With {
                            .CartID = CInt(rdr("CartID")),
                            .Quantity = CInt(rdr("Quantity")),
                            .LblNum = lblNum
                        }

                        ' Add panel to TableLayoutPanel3
                        TableLayoutPanel3.RowCount += 1
                        TableLayoutPanel3.RowStyles.Add(New RowStyle(SizeType.AutoSize))
                        TableLayoutPanel3.Controls.Add(pnl, 0, TableLayoutPanel3.RowCount - 1)
                    End While
                End Using
            End Using
        End Using

        ' Recalculate totals
        CalculateCartTotals()
        LoadProducts()
    End Sub



' Increase quantity
    Private Sub CheckoutPlus_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim lbl As Label = DirectCast(sender, Label)
        Dim pnl As Panel = DirectCast(lbl.Parent, Panel)
        Dim tag As CartTag = DirectCast(pnl.Tag, CartTag)

        tag.Quantity += 1
        tag.LblNum.Text = tag.Quantity.ToString()

        ' Update DB
        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "UPDATE Uniqlo_Cart SET Quantity=@qty WHERE CartID=@id"
            Using cmd As New SqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@qty", tag.Quantity)
                cmd.Parameters.AddWithValue("@id", tag.CartID)
                cmd.ExecuteNonQuery()
            End Using
        End Using

        CalculateCartTotals()
    End Sub

    ' Decrease quantity
    Private Sub CheckoutMinus_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim lbl As Label = DirectCast(sender, Label)
        Dim pnl As Panel = DirectCast(lbl.Parent, Panel)
        Dim tag As CartTag = DirectCast(pnl.Tag, CartTag)

        If tag.Quantity > 1 Then
            tag.Quantity -= 1
            tag.LblNum.Text = tag.Quantity.ToString()

            ' Update DB
            Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
            Using conn As New SqlConnection(connStr)
                conn.Open()
                Dim sql As String = "UPDATE Uniqlo_Cart SET Quantity=@qty WHERE CartID=@id"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@qty", tag.Quantity)
                    cmd.Parameters.AddWithValue("@id", tag.CartID)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
        End If

        CalculateCartTotals()
    End Sub

    ' Remove item
    Private Sub CheckoutRemove_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim lbl As Label = DirectCast(sender, Label)
        Dim pnl As Panel = DirectCast(lbl.Parent, Panel)
        Dim tag As CartTag = DirectCast(pnl.Tag, CartTag)

        ' Delete from DB
        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "DELETE FROM Uniqlo_Cart WHERE CartID=@id"
            Using cmd As New SqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@id", tag.CartID)
                cmd.ExecuteNonQuery()
            End Using
        End Using

        ' Remove from UI
        TableLayoutPanel3.Controls.Remove(pnl)
        pnl.Dispose()

        CalculateCartTotals()
    End Sub

    Private Sub LoadStockChart()
        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Dim unitSize As Integer = 10   ' Each "brick" represents 10 stock units
        Dim lowStockThreshold As Integer = 100

        ' Clear previous series
        Chart2.Series.Clear()

        ' Create series
        Dim series As New DataVisualization.Charting.Series()
        series.ChartType = DataVisualization.Charting.SeriesChartType.Column
        series.IsValueShownAsLabel = True

        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "SELECT ProductName, Stock FROM Uniqlo"
            Using cmd As New SqlCommand(sql, conn)
                Using rdr As SqlDataReader = cmd.ExecuteReader()
                    While rdr.Read()
                        Dim name As String = rdr("ProductName").ToString()
                        Dim stock As Integer = Convert.ToInt32(rdr("Stock"))

                        ' Calculate number of bricks
                        Dim bricks As Integer = Math.Max(1, stock \ unitSize)

                        ' Create data point
                        Dim dp As New DataVisualization.Charting.DataPoint()
                        dp.AxisLabel = name
                        dp.YValues = New Double() {bricks}

                        ' Color red if stock < threshold
                        dp.Color = If(stock < lowStockThreshold, Color.Red, Color.Green)

                        series.Points.Add(dp)
                    End While
                End Using
            End Using
        End Using

        Chart2.Series.Add(series)
        Chart2.ChartAreas(0).AxisX.Interval = 1
        Chart2.ChartAreas(0).AxisX.LabelStyle.Angle = -45
        Chart2.ChartAreas(0).AxisX.LabelStyle.Font = New Font("Montserrat", 8)
        Chart2.ChartAreas(0).AxisY.Title = "Bricks (Stock Units / " & unitSize & ")"
    End Sub









    Private Sub Form3_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

        If Me.DesignMode Then Return

        ' Load products into TableLayoutPanel
        LoadProducts()
        If lblTitle.Text = "Edit Stock" Then
            btnDelete.Visible = True
        Else
            btnDelete.Visible = False
        End If

        ' Refresh layout
        TableLayoutPanel1.PerformLayout()
        TableLayoutPanel1.Refresh()
        LoadSalesProducts()
        CalculateCartTotals()

        UpdateDashboardStats()
        LoadStockChart()

        ' Load chart (if you have this function)
        LoadChart()




    End Sub
    Private Sub UpdateDashboardStats()
        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"

        Dim totalProd As Integer = 0
        Dim totalSales As Decimal = 0
        Dim lowStock As Integer = 0

        Using conn As New SqlConnection(connStr)
            conn.Open()

            ' Total Products
            Using cmd As New SqlCommand("SELECT COUNT(*) FROM Uniqlo", conn)
                totalProd = Convert.ToInt32(cmd.ExecuteScalar())
            End Using

            ' Total Sales (sum of Price * Stock)
            Using cmd As New SqlCommand("SELECT ISNULL(SUM(Price * Stock),0) FROM Uniqlo", conn)
                totalSales = Convert.ToDecimal(cmd.ExecuteScalar())
            End Using

            ' Low Stock Products (stock < 100)
            Using cmd As New SqlCommand("SELECT COUNT(*) FROM Uniqlo WHERE Stock < 100", conn)
                lowStock = Convert.ToInt32(cmd.ExecuteScalar())
            End Using
        End Using

        ' Truncate totalSales to 4 decimal places
        Dim displaySales As String = "₱" & totalSales.ToString("F4")

        ' Truncate to 9 characters if too long
        If displaySales.Length > 9 Then
            displaySales = displaySales.Substring(0, 9)
            lblTotalSales.Font = New Font(lblTotalSales.Font.FontFamily, 10) ' smaller font
        Else
            lblTotalSales.Font = New Font(lblTotalSales.Font.FontFamily, 11) ' default font
        End If

        lblTotalSales.Text = displaySales

        ' Update labels
        lblTotalProd.Text = totalProd.ToString()
        lblLowStock.Text = lowStock.ToString()
    End Sub


    Private Sub CalculateCartTotals()
        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Dim totalQuantity As Integer = 0
        Dim totalPrice As Decimal = 0

        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "SELECT Quantity, Price FROM Uniqlo_Cart"
            Using cmd As New SqlCommand(sql, conn)
                Using rdr As SqlDataReader = cmd.ExecuteReader()
                    While rdr.Read()
                        Dim qty As Integer = Convert.ToInt32(rdr("Quantity"))
                        Dim price As Decimal = Convert.ToDecimal(rdr("Price"))

                        totalQuantity += qty
                        totalPrice += price * qty
                    End While
                End Using
            End Using
        End Using

        ' Display the totals
        ' Display the totals with commas and 2 decimals
        lblTotals.Text = totalPrice.ToString("N2")


    End Sub

    ' ✅ Handles CheckedChanged for all 6 checkboxes
    Private Sub chk_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) _
        Handles ChkHoodie.CheckedChanged, ChkPolo.CheckedChanged, ChkTshirt.CheckedChanged, ChkSweather.CheckedChanged, ChkPants.CheckedChanged, ChkDress.CheckedChanged

        Dim chk As CheckBox = DirectCast(sender, CheckBox)

        ' Count how many are checked
        Dim totalChecked As Integer =
            {ChkHoodie, ChkPolo, ChkTshirt, ChkSweather, ChkPants, ChkDress}.Count(Function(c) c.Checked)

        ' If over 3, undo the last check
        If totalChecked > 3 Then
            chk.Checked = False
            MessageBox.Show("You can only choose up to 3 items.", "Limit Reached", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Apply style
        If chk.Checked Then
            chk.BackColor = Color.Red
            chk.ForeColor = Color.White
        Else
            chk.BackColor = Color.Transparent
            chk.ForeColor = Color.Black
        End If
    End Sub


    Private Sub TabPage2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage2.Click

    End Sub

    Private Sub TabPage3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage3.Click

    End Sub
    Private Sub chkHoodie_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ChkHoodie.CheckedChanged
        ApplyCheckBoxStyle(ChkHoodie)
    End Sub

    Private Sub chkPolo_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ChkPolo.CheckedChanged
        ApplyCheckBoxStyle(ChkPolo)
    End Sub

    Private Sub chkTshirt_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ChkTshirt.CheckedChanged
        ApplyCheckBoxStyle(ChkTshirt)
    End Sub

    Private Sub chkSweather_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ChkSweather.CheckedChanged
        ApplyCheckBoxStyle(ChkSweather)
    End Sub

    Private Sub chkPants_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ChkPants.CheckedChanged
        ApplyCheckBoxStyle(ChkPants)
    End Sub

    Private Sub chkDress_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ChkDress.CheckedChanged
        ApplyCheckBoxStyle(ChkDress)
    End Sub


    ' 🔹 Helper method to apply style
    Private Sub ApplyCheckBoxStyle(ByVal chk As CheckBox)
        If chk.Checked Then
            chk.BackColor = Color.Red
            chk.ForeColor = Color.White
        Else
            chk.BackColor = Color.Transparent
            chk.ForeColor = Color.Black
        End If
    End Sub


Private Sub btnUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpload.Click
        Using ofd As New OpenFileDialog()
            ofd.Title = "Select Product Image"
            ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp"

            If ofd.ShowDialog() = DialogResult.OK Then
                ' Show image in PictureBox
                picProd.Image = Image.FromFile(ofd.FileName)

                ' Create folder if not exists
                Dim savePath As String = "C:\UniqloImages\"  ' ⚠️ change folder path if needed
                If Not IO.Directory.Exists(savePath) Then
                    IO.Directory.CreateDirectory(savePath)
                End If

                ' Copy selected image into folder (or reuse if exists)
                Dim fileName As String = IO.Path.GetFileName(ofd.FileName)
                Dim finalPath As String = IO.Path.Combine(savePath, fileName)

                If Not IO.File.Exists(finalPath) Then
                    IO.File.Copy(ofd.FileName, finalPath, False)
                End If

                ' Always set the Tag (DB storage path)
                picProd.Tag = finalPath
            End If
        End Using
    End Sub



    Private Sub btnAddProd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddProd.Click
        ' 1. Validate required fields
        ' Validate text fields only
        If String.IsNullOrWhiteSpace(txtProdName.Text) OrElse
           String.IsNullOrWhiteSpace(txtColor.Text) OrElse
           String.IsNullOrWhiteSpace(txtStock.Text) OrElse
           String.IsNullOrWhiteSpace(txtPrice.Text) Then
            MessageBox.Show("Please fill all text fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If


        If btnAddProd.Text = "Add Product" AndAlso picProd.Tag Is Nothing Then
            MessageBox.Show("Please upload an image.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If


        ' 2. Get Categories
        Dim categoriesList As New List(Of String)
        If ChkHoodie.Checked Then categoriesList.Add("Hoodie")
        If ChkPolo.Checked Then categoriesList.Add("Polo")
        If ChkTshirt.Checked Then categoriesList.Add("Tshirt")
        If ChkSweather.Checked Then categoriesList.Add("Sweather")
        If ChkPants.Checked Then categoriesList.Add("Pants")
        If ChkDress.Checked Then categoriesList.Add("Dress")

        If categoriesList.Count = 0 Then
            MessageBox.Show("Please select at least one category.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' 3. Get Sizes
        Dim sizesList As New List(Of String)
        If chkS.Checked Then sizesList.Add("S")
        If chkM.Checked Then sizesList.Add("M")
        If chkL.Checked Then sizesList.Add("L")
        If chkXL.Checked Then sizesList.Add("XL")
        If chkXXL.Checked Then sizesList.Add("XXL")
        If chkXXXL.Checked Then sizesList.Add("XXXL")

        If sizesList.Count = 0 Then
            MessageBox.Show("Please select at least one size.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim connStr As String = "Server=.\SQLEXPRESS;Database=DBCRUD;Trusted_Connection=True;"

        ' ------------------------------------------------------------
        ' ADD PRODUCT MODE
        ' ------------------------------------------------------------
        If btnAddProd.Text = "Add Product" Then
            Using conn As New SqlConnection(connStr)
                conn.Open()

                ' Check for duplicate (same ProductName and Color)
                Dim checkDup As String = "SELECT COUNT(*) FROM Uniqlo WHERE ProductName=@ProductName AND Colors=@Colors"
                Using cmdCheck As New SqlCommand(checkDup, conn)
                    cmdCheck.Parameters.AddWithValue("@ProductName", txtProdName.Text.Trim())
                    cmdCheck.Parameters.AddWithValue("@Colors", txtColor.Text.Trim())




                    Dim count As Integer = Convert.ToInt32(cmdCheck.ExecuteScalar())
                    If count > 0 Then
                        MessageBox.Show("This product with the same name and color already exists!", "Duplicate Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Exit Sub
                    End If
                End Using

                Dim imagePath As String = ""

                If picProd.Tag IsNot Nothing AndAlso File.Exists(picProd.Tag.ToString()) Then
                    ' Image already exists, just get the path
                    imagePath = picProd.Tag.ToString()
                Else
                    ' If user selected a new image, store its path
                    ' Here you could have file copy logic if needed
                    MessageBox.Show("Please upload an image.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Exit Sub
                End If


                ' Insert new product with Price
                Dim sql As String = "INSERT INTO Uniqlo (ProductName, Colors, Stock, Categories, Sizes, ImagePath, Price) " &
                                    "VALUES (@ProductName, @Colors, @Stock, @Categories, @Sizes, @ImagePath, @Price)"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@ProductName", txtProdName.Text.Trim())
                    cmd.Parameters.AddWithValue("@Colors", txtColor.Text.Trim())
                    cmd.Parameters.AddWithValue("@Stock", Convert.ToInt32(txtStock.Text.Trim()))
                    cmd.Parameters.AddWithValue("@Categories", String.Join(", ", categoriesList))
                    cmd.Parameters.AddWithValue("@Sizes", String.Join(", ", sizesList))
                    cmd.Parameters.AddWithValue("@ImagePath", imagePath)
                    cmd.Parameters.AddWithValue("@Price", Convert.ToDecimal(txtPrice.Text.Trim()))
                    cmd.ExecuteNonQuery()
                End Using

            End Using

            ' If image path already exists, use it



            MessageBox.Show("Product added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadProducts()
            LoadSalesProducts()
            LoadChart()
            LoadStockChart()
            LoadCheckoutItems()
            LoadStockChart()



            TabControl1.SelectedTab = TabPage2

            ' ------------------------------------------------------------
            ' EDIT STOCK MODE
            ' ------------------------------------------------------------
        ElseIf btnAddProd.Text = "Edit Stock" Then
            Dim productId As Integer = CInt(btnAddProd.Tag)

            ' Step 1: Read existing values from DB
            Dim existingName As String = ""
            Dim existingColor As String = ""
            Dim existingStock As Integer = 0
            Dim existingSizes As String = ""
            Dim existingCategories As String = ""
            Dim existingImage As String = ""
            Dim existingPrice As Decimal = 0

            Using conn As New SqlConnection(connStr)
                conn.Open()

                Dim sqlRead As String = "SELECT ProductName, Colors, Stock, Sizes, Categories, ImagePath, Price FROM Uniqlo WHERE ProductID=@id"
                Using cmdRead As New SqlCommand(sqlRead, conn)
                    cmdRead.Parameters.AddWithValue("@id", productId)
                    Using rdr As SqlDataReader = cmdRead.ExecuteReader()
                        If rdr.Read() Then
                            existingName = rdr("ProductName").ToString()
                            existingColor = rdr("Colors").ToString()
                            existingStock = Convert.ToInt32(rdr("Stock"))
                            existingSizes = rdr("Sizes").ToString()
                            existingCategories = rdr("Categories").ToString()
                            existingImage = rdr("ImagePath").ToString()
                            existingPrice = Convert.ToDecimal(rdr("Price"))
                        End If
                    End Using
                End Using
            End Using

            ' Step 2: Compare and update only changed fields
            Using conn As New SqlConnection(connStr)
                conn.Open()

                Dim sqlUpdate As String = "UPDATE Uniqlo SET "
                Dim updateList As New List(Of String)
                Dim cmd As New SqlCommand()
                cmd.Connection = conn

                If txtProdName.Text.Trim() <> existingName Then
                    updateList.Add("ProductName=@name")
                    cmd.Parameters.AddWithValue("@name", txtProdName.Text.Trim())
                End If

                If txtColor.Text.Trim() <> existingColor Then
                    updateList.Add("Colors=@color")
                    cmd.Parameters.AddWithValue("@color", txtColor.Text.Trim())
                End If

                If Convert.ToInt32(txtStock.Text.Trim()) <> existingStock Then
                    updateList.Add("Stock=@stock")
                    cmd.Parameters.AddWithValue("@stock", Convert.ToInt32(txtStock.Text.Trim()))
                End If

                Dim newSizes As String = String.Join(", ", sizesList)
                If newSizes <> existingSizes Then
                    updateList.Add("Sizes=@sizes")
                    cmd.Parameters.AddWithValue("@sizes", newSizes)
                End If

                Dim newCategories As String = String.Join(", ", categoriesList)
                If newCategories <> existingCategories Then
                    updateList.Add("Categories=@cat")
                    cmd.Parameters.AddWithValue("@cat", newCategories)
                End If

                ' Only update image if user selected a new one
                If picProd.Tag IsNot Nothing AndAlso picProd.Tag.ToString() <> existingImage Then
                    updateList.Add("ImagePath=@image")
                    cmd.Parameters.AddWithValue("@image", picProd.Tag.ToString())
                End If


                If Convert.ToDecimal(txtPrice.Text.Trim()) <> existingPrice Then
                    updateList.Add("Price=@price")
                    cmd.Parameters.AddWithValue("@price", Convert.ToDecimal(txtPrice.Text.Trim()))
                End If

                ' Only execute if any field changed
                If updateList.Count > 0 Then
                    sqlUpdate &= String.Join(", ", updateList)
                    sqlUpdate &= " WHERE ProductID=@id"
                    cmd.CommandText = sqlUpdate
                    cmd.Parameters.AddWithValue("@id", productId)
                    cmd.ExecuteNonQuery()

                    MessageBox.Show("Product updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("No changes detected.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using

            LoadProducts()
            LoadSalesProducts()
            LoadChart()
            LoadStockChart()

            TabControl1.SelectedTab = TabPage2
        End If
    End Sub




    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ' --- Clear textboxes ---
        For Each ctrl As Control In TabPage3.Controls
            If TypeOf ctrl Is TextBox Then
                DirectCast(ctrl, TextBox).Clear()
            End If
        Next

        ' --- Clear picture ---
        picProd.Image = Nothing
        picProd.Tag = Nothing

        ' --- Reset title ---
        lblTitle.Text = "All Stocks"

        ' --- Uncheck checkboxes ---
        For Each ctrl As Control In TabPage3.Controls
            If TypeOf ctrl Is CheckBox Then
                DirectCast(ctrl, CheckBox).Checked = False
            End If
        Next

        ' --- Switch to TabPage2 ---
        TabControl1.SelectedTab = TabPage2
    End Sub


    Private Sub Guna2Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Guna2Button2.Click
        TabControl1.SelectedTab = TabPage3
        lblTitle.Text = "Add Product"
    End Sub

    Private Sub btnAddProduct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddProduct.Click
        lblTitle.Text = "Add Product"
        TabControl1.SelectedTab = TabPage3
    End Sub

    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub lblDashboard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblDashboard.Click
        TabControl1.SelectedTab = TabPage1
        lblTitle.Text = "Dashboard"
    End Sub

    Private Sub lblProduct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblProduct.Click
        TabControl1.SelectedTab = TabPage2
        lblTitle.Text = "Products Inventory"
    End Sub

    Private Sub lblLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblLogOut.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub txtStock_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles txtStock.KeyPress
        ' Allow only digits and control keys (like Backspace)
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub TableLayoutPanel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles TableLayoutPanel1.Paint

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If btnAddProd.Tag Is Nothing Then
            MessageBox.Show("No product selected to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim productId As Integer = CInt(btnAddProd.Tag)
        Dim imagePath As String = If(picProd.Tag, String.Empty) ' store path when loading product

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this product?",
                                                     "Confirm Delete",
                                                     MessageBoxButtons.YesNo,
                                                     MessageBoxIcon.Warning)

        If result = DialogResult.Yes Then
            Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
            Using conn As New SqlConnection(connStr)
                conn.Open()

                Dim sql As String = "DELETE FROM Uniqlo WHERE ProductID=@id"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@id", productId)
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            ' ✅ Delete image from folder if exists
            If Not String.IsNullOrEmpty(imagePath) AndAlso IO.File.Exists(imagePath) Then
                Try
                    IO.File.Delete(imagePath)
                Catch ex As Exception
                    MessageBox.Show("Failed to delete product image: " & ex.Message,
                                    "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End Try
            End If

            MessageBox.Show("Product deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' --------------------------
            ' Clear all input fields
            ' --------------------------
            txtProdName.Clear()
            txtColor.Clear()
            txtStock.Clear()
            txtPrice.Clear()
            picProd.Image = Nothing
            picProd.Tag = Nothing

            ' Uncheck all checkboxes
            For Each ctrl As Control In Me.Controls
                If TypeOf ctrl Is CheckBox Then
                    DirectCast(ctrl, CheckBox).Checked = False
                End If
            Next

            ' Reset labels and buttons
            lblTitle.Text = "Add Product"
            btnAddProd.Text = "Add Product"
            btnAddProd.Tag = Nothing
            btnDelete.Visible = False

            ' Refresh product list and go back to product tab
            LoadProducts()
            LoadSalesProducts()
            LoadCheckoutItems()
            TabControl1.SelectedTab = TabPage2
        End If
    End Sub


    Private Sub TabPage4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage4.Click

    End Sub
    Private Sub LoadSalesProducts()
        ' Reset TableLayoutPanel
        With TableLayoutPanel2
            .Controls.Clear()
            .ColumnCount = 3   ' ⬅ 3 panels per row
            .RowCount = 0
            .Dock = DockStyle.Fill
            .CellBorderStyle = TableLayoutPanelCellBorderStyle.None

            ' Enable only vertical scroll
            .AutoScroll = True
            .HorizontalScroll.Enabled = False
            .HorizontalScroll.Visible = False
            .VerticalScroll.Enabled = True
            .VerticalScroll.Visible = True
        End With


        ' Make each column equal width
        ' Clear old styles
        ' Example: 3 columns, 3 rows equally spaced
        TableLayoutPanel2.ColumnStyles.Clear()
        TableLayoutPanel2.RowStyles.Clear()

        ' Set 3 columns, each 33.33%
        TableLayoutPanel2.ColumnCount = 3
        For i As Integer = 1 To 3
            TableLayoutPanel2.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100.0! / 3))
        Next

        ' Set 3 rows, each 33.33%
        TableLayoutPanel2.RowCount = 3
        For i As Integer = 1 To 2
            TableLayoutPanel2.RowStyles.Add(New RowStyle(SizeType.Percent, 50.0!))
        Next





        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"

        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "SELECT ProductID, ProductName, Price, ImagePath FROM Uniqlo"
            Using cmd As New SqlCommand(sql, conn)
                Using rdr As SqlDataReader = cmd.ExecuteReader()
                    While rdr.Read()
                        ' Create panel (product card)
                        Dim pnl As New Panel()
                        pnl.Size = New Size(167, 256)
                        pnl.BackColor = Color.White

                        ' PictureBox
                        Dim picSale As New PictureBox()
                        picSale.Size = New Size(135, 114)
                        picSale.Location = New Point(16, 15)
                        picSale.SizeMode = PictureBoxSizeMode.StretchImage
                        If Not IsDBNull(rdr("ImagePath")) AndAlso File.Exists(rdr("ImagePath").ToString()) Then
                            picSale.Image = Image.FromFile(rdr("ImagePath").ToString())
                        End If
                        pnl.Controls.Add(picSale)

                        ' Product Name (Label)
                        Dim lblSName As New Label()
                        lblSName.Location = New Point(18, 143)
                        lblSName.Size = New Size(130, 25)
                        lblSName.Text = rdr("ProductName").ToString()
                        lblSName.Font = New Font("Montserrat", 11)
                        lblSName.ForeColor = Color.Black
                        pnl.Controls.Add(lblSName)

                        ' Product Price (Label)
                        Dim lblSPrice As New Label()
                        lblSPrice.Location = New Point(18, 170)
                        lblSPrice.Size = New Size(130, 25)
                        Dim priceValue As Decimal = 0
                        If Not IsDBNull(rdr("Price")) Then
                            Decimal.TryParse(rdr("Price").ToString(), priceValue)
                        End If
                        lblSPrice.Text = priceValue.ToString("C2")
                        lblSPrice.Font = New Font("Montserrat", 9)
                        lblSPrice.ForeColor = Color.Black
                        pnl.Controls.Add(lblSPrice)

                        ' Add to Sales Button
                        Dim btnAddSales As New Button()
                        btnAddSales.Size = New Size(130, 30)
                        btnAddSales.Location = New Point(16, 200)
                        btnAddSales.Text = "Add to Sale"
                        btnAddSales.FlatStyle = FlatStyle.Flat
                        btnAddSales.BackColor = Color.Firebrick
                        btnAddSales.ForeColor = Color.White
                        btnAddSales.Font = New Font("Montserrat", 9)
                        btnAddSales.Tag = rdr("ProductID")
                        AddHandler btnAddSales.Click, AddressOf BtnAddSales_Click
                        pnl.Controls.Add(btnAddSales)

                        ' Add panel to TableLayoutPanel
                        TableLayoutPanel2.Controls.Add(pnl)
                    End While
                End Using
            End Using
        End Using
    End Sub




    Private Sub BtnAddSales_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim btn As Button = DirectCast(sender, Button)
        Dim productId As Integer = CInt(btn.Tag)

        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Dim newCartId As Integer = 0
        Dim newQty As Integer = 0

        Using conn As New SqlConnection(connStr)
            conn.Open()

            ' Check if product already in cart
            Dim checkSql As String = "SELECT CartID, Quantity FROM Uniqlo_Cart WHERE ProductID=@ProductID"
            Using cmdCheck As New SqlCommand(checkSql, conn)
                cmdCheck.Parameters.AddWithValue("@ProductID", productId)
                Using rdr As SqlDataReader = cmdCheck.ExecuteReader()
                    If rdr.Read() Then
                        newCartId = CInt(rdr("CartID"))
                        newQty = CInt(rdr("Quantity")) + 1
                    End If
                End Using
            End Using

            If newCartId > 0 Then
                ' Update quantity
                Dim updateSql As String = "UPDATE Uniqlo_Cart SET Quantity=@qty WHERE CartID=@id"
                Using cmdUpdate As New SqlCommand(updateSql, conn)
                    cmdUpdate.Parameters.AddWithValue("@qty", newQty)
                    cmdUpdate.Parameters.AddWithValue("@id", newCartId)
                    cmdUpdate.ExecuteNonQuery()
                End Using
            Else
                ' Insert new
                Dim insertSql As String = "INSERT INTO Uniqlo_Cart (ProductID, ProductName, Price, Quantity, ImagePath) " &
                                          "SELECT ProductID, ProductName, Price, 1, ImagePath FROM Uniqlo WHERE ProductID=@ProductID"
                Using cmdInsert As New SqlCommand(insertSql, conn)
                    cmdInsert.Parameters.AddWithValue("@ProductID", productId)
                    cmdInsert.ExecuteNonQuery()
                End Using
            End If
        End Using

        Panel5.Visible = True

        ' Reload all cart items
        LoadCheckoutItems()
    End Sub






    Private Sub lblSales_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblSales.Click
        TabControl1.SelectedTab = TabPage4
        lblTitle.Text = "Sales Inventory"
    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Panel5_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs)

    End Sub

    Private Sub lblPlus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblPlus.Click
        Dim lbl As Label = DirectCast(sender, Label)
        Dim pnl As Panel = DirectCast(lbl.Parent, Panel)
        Dim info = pnl.Tag

        info.Quantity += 1
        info.LblNum.Text = info.Quantity.ToString()

        ' Update DB
        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "UPDATE Uniqlo_Cart SET Quantity=@qty WHERE CartID=@id"
            Using cmd As New SqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@qty", info.Quantity)
                cmd.Parameters.AddWithValue("@id", info.CartID)
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    Private Sub lblMinus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMinus.Click
        Dim lbl As Label = DirectCast(sender, Label)
        Dim pnl As Panel = DirectCast(lbl.Parent, Panel)
        Dim info = pnl.Tag

        If info.Quantity > 1 Then
            info.Quantity -= 1
            info.LblNum.Text = info.Quantity.ToString()

            ' Update DB
            Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
            Using conn As New SqlConnection(connStr)
                conn.Open()
                Dim sql As String = "UPDATE Uniqlo_Cart SET Quantity=@qty WHERE CartID=@id"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@qty", info.Quantity)
                    cmd.Parameters.AddWithValue("@id", info.CartID)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
        End If
    End Sub

    Private Sub lblClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblClose.Click
        Panel5.Visible = False

    End Sub

    Private Sub Guna2Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnlPayment.Paint

    End Sub

    Private Sub Label27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label27.Click

    End Sub

    Private Sub btnComplete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnComplete.Click
        ' Show payment panel
        pnlPayment.Visible = True

        ' Clear previous items in TableLayoutPanel4
        TableLayoutPanel4.Controls.Clear()
        TableLayoutPanel4.ColumnCount = 2   ' Product Name | Quantity
        TableLayoutPanel4.RowCount = 0
        TableLayoutPanel4.Padding = New Padding(0)
        TableLayoutPanel4.CellBorderStyle = TableLayoutPanelCellBorderStyle.None
        TableLayoutPanel4.AutoScroll = True

        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "SELECT ProductName, Quantity FROM Uniqlo_Cart"
            Using cmd As New SqlCommand(sql, conn)
                Using rdr As SqlDataReader = cmd.ExecuteReader()
                    While rdr.Read()
                        ' Add row
                        TableLayoutPanel4.RowCount += 1
                        TableLayoutPanel4.RowStyles.Add(New RowStyle(SizeType.AutoSize))

                        ' Product Name label
                        Dim lblProdName As New Label()
                        lblProdName.Text = rdr("ProductName").ToString()
                        lblProdName.Font = New Font("Montserrat", 9)
                        lblProdName.ForeColor = Color.Black
                        lblProdName.AutoSize = True
                        TableLayoutPanel4.Controls.Add(lblProdName, 0, TableLayoutPanel4.RowCount - 1)

                        ' Quantity label
                        Dim lblQty As New Label()
                        lblQty.Text = rdr("Quantity").ToString()
                        lblQty.Font = New Font("Montserrat", 9)
                        lblQty.ForeColor = Color.Black
                        lblQty.AutoSize = True
                        TableLayoutPanel4.Controls.Add(lblQty, 1, TableLayoutPanel4.RowCount - 1)
                    End While
                End Using
            End Using
        End Using

        ' Set total label
        lblTotal.Text = lblTotals.Text  ' Assuming lblTotals has total price
    End Sub

    Private Sub btnPayment_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnPayment.Click
        ' Clear all items from Uniqlo_Cart
        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"
        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim sql As String = "DELETE FROM Uniqlo_Cart"
            Using cmd As New SqlCommand(sql, conn)
                cmd.ExecuteNonQuery()
            End Using
        End Using

        ' Clear the checkout UI
        TableLayoutPanel3.Controls.Clear()
        lblTotals.Text = "₱0.00"

        ' Hide payment panels
        pnlPayment.Visible = False
        pnlSaleschkOut.Visible = False
        LoadProducts()
        LoadSalesProducts()
        LoadCheckoutItems()

        ' Go back to main tab
        TabControl1.SelectedTab = TabPage1

        ' Show thank you message
        MessageBox.Show("Thank you for your purchase!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub lblReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblReport.Click
        TabControl1.SelectedTab = TabPage5
        lblTitle.Text = "Report Status"
    End Sub

    Private Sub TableLayoutPanel3_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles TableLayoutPanel3.Paint

    End Sub

    Private Sub Label9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbFilter.SelectedIndexChanged

    End Sub
End Class