﻿Imports System.Data.SqlClient

Public Class Form2

    Private Sub Form2_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        ' Initialize progress bar
        ProgressBar1.Value = 0
        ProgressBar1.Step = 20

        Dim connStr As String = "Data Source=.\SQLEXPRESS;Initial Catalog=DBCRUD;Integrated Security=True"

        Try
            Using conn As New SqlConnection(connStr)
                conn.Open()
                ProgressBar1.PerformStep()

                ' Check if table exists
                Dim checkTable As String = "IF OBJECT_ID('dbo.Uniqlo', 'U') IS NOT NULL SELECT 1 ELSE SELECT 0"
                Using cmd As New SqlCommand(checkTable, conn)
                    cmd.CommandTimeout = 30
                    Dim exists As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                    ProgressBar1.PerformStep()

                    If exists = 0 Then
                        ' Table does not exist → create it
                        Dim createTable As String =
                            "CREATE TABLE [dbo].[Uniqlo](" &
                            "ProductID INT IDENTITY(1,1) PRIMARY KEY, " &
                            "ProductName NVARCHAR(100) NOT NULL, " &
                            "Colors NVARCHAR(200) NOT NULL, " &
                            "Stock INT NOT NULL, " &
                            "Categories NVARCHAR(200) NOT NULL, " &
                            "Sizes NVARCHAR(200) NOT NULL, " &
                            "ImagePath NVARCHAR(500) NOT NULL" &
                            ")"

                        Using cmdCreate As New SqlCommand(createTable, conn)
                            cmdCreate.CommandTimeout = 30
                            cmdCreate.ExecuteNonQuery()
                        End Using
                    End If

                    ProgressBar1.PerformStep()
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
            Exit Sub
        End Try

        ' Complete the progress bar
        ProgressBar1.Value = 100

        ' Start a timer for 2-second delay before opening Form3
        Dim t As New Timer()
        t.Interval = 2000 ' 2000ms = 2 seconds
        AddHandler t.Tick,
            Sub(sender2, e2)
                t.Stop()

                Dim f3 As New Form3()

                ' --- Make Form3 fullscreen ---
                f3.FormBorderStyle = Windows.Forms.FormBorderStyle.None
                f3.WindowState = FormWindowState.Maximized
                f3.Bounds = Screen.PrimaryScreen.Bounds
                f3.TopMost = True

                f3.Show()
                Me.Hide()
            End Sub
        t.Start()
    End Sub

End Class
