﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ChartArea5 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend5 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series5 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea6 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend6 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series6 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblLogOut = New System.Windows.Forms.Label()
        Me.lblReport = New System.Windows.Forms.Label()
        Me.lblSales = New System.Windows.Forms.Label()
        Me.lblProduct = New System.Windows.Forms.Label()
        Me.lblDashboard = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Guna2Elipse2 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Guna2Elipse3 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Label16 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.pnlSaleschkOut = New System.Windows.Forms.Panel()
        Me.lblRemove = New System.Windows.Forms.Label()
        Me.lblNum = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.lblPlus = New System.Windows.Forms.Label()
        Me.lblMinus = New System.Windows.Forms.Label()
        Me.lblSPrice = New System.Windows.Forms.Label()
        Me.lblSName = New System.Windows.Forms.Label()
        Me.picSales = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblTotals = New System.Windows.Forms.Label()
        Me.btnComplete = New Guna.UI2.WinForms.Guna2Button()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.lblClose = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnlPayment = New Guna.UI2.WinForms.Guna2Panel()
        Me.btnPayment = New Guna.UI2.WinForms.Guna2Button()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblProdName = New System.Windows.Forms.Label()
        Me.lblPQuanity = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.txtSPrice = New System.Windows.Forms.Label()
        Me.txtSName = New System.Windows.Forms.Label()
        Me.btnAddSales = New System.Windows.Forms.Button()
        Me.picSale = New System.Windows.Forms.PictureBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.txtPrice = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnQrBar = New Guna.UI2.WinForms.Guna2Button()
        Me.btnDelete = New Guna.UI2.WinForms.Guna2Button()
        Me.btnUpload = New Guna.UI2.WinForms.Guna2Button()
        Me.btnCancel = New Guna.UI2.WinForms.Guna2Button()
        Me.btnAddProd = New Guna.UI2.WinForms.Guna2Button()
        Me.chkXXXL = New System.Windows.Forms.CheckBox()
        Me.chkXXL = New System.Windows.Forms.CheckBox()
        Me.chkXL = New System.Windows.Forms.CheckBox()
        Me.chkL = New System.Windows.Forms.CheckBox()
        Me.chkM = New System.Windows.Forms.CheckBox()
        Me.chkS = New System.Windows.Forms.CheckBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.ChkDress = New System.Windows.Forms.CheckBox()
        Me.ChkPants = New System.Windows.Forms.CheckBox()
        Me.ChkSweather = New System.Windows.Forms.CheckBox()
        Me.ChkTshirt = New System.Windows.Forms.CheckBox()
        Me.ChkPolo = New System.Windows.Forms.CheckBox()
        Me.ChkHoodie = New System.Windows.Forms.CheckBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtStock = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtColor = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtProdName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape4 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape3 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape2 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.picQRBAR = New System.Windows.Forms.PictureBox()
        Me.picProd = New System.Windows.Forms.PictureBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.cmbFilter = New System.Windows.Forms.ComboBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnViewStock2 = New Guna.UI2.WinForms.Guna2Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.btnViewStock = New Guna.UI2.WinForms.Guna2Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Guna2Button2 = New Guna.UI2.WinForms.Guna2Button()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.lblLowStock = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblTotalSales = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.btnAddProduct = New Guna.UI2.WinForms.Guna2Button()
        Me.lblTotalProd = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Chart2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.pnlSaleschkOut.SuspendLayout()
        CType(Me.picSales, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.pnlPayment.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.picSale, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.picQRBAR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picProd, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.lblLogOut)
        Me.Panel1.Controls.Add(Me.lblReport)
        Me.Panel1.Controls.Add(Me.lblSales)
        Me.Panel1.Controls.Add(Me.lblProduct)
        Me.Panel1.Controls.Add(Me.lblDashboard)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(180, 991)
        Me.Panel1.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(54, 166)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Admin"
        '
        'lblLogOut
        '
        Me.lblLogOut.AutoSize = True
        Me.lblLogOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogOut.ForeColor = System.Drawing.Color.White
        Me.lblLogOut.Location = New System.Drawing.Point(39, 922)
        Me.lblLogOut.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLogOut.Name = "lblLogOut"
        Me.lblLogOut.Size = New System.Drawing.Size(82, 25)
        Me.lblLogOut.TabIndex = 5
        Me.lblLogOut.Text = "Log Out"
        '
        'lblReport
        '
        Me.lblReport.AutoSize = True
        Me.lblReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReport.ForeColor = System.Drawing.Color.White
        Me.lblReport.Location = New System.Drawing.Point(39, 588)
        Me.lblReport.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblReport.Name = "lblReport"
        Me.lblReport.Size = New System.Drawing.Size(69, 25)
        Me.lblReport.TabIndex = 4
        Me.lblReport.Text = "Report"
        '
        'lblSales
        '
        Me.lblSales.AutoSize = True
        Me.lblSales.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSales.ForeColor = System.Drawing.Color.White
        Me.lblSales.Location = New System.Drawing.Point(52, 509)
        Me.lblSales.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSales.Name = "lblSales"
        Me.lblSales.Size = New System.Drawing.Size(62, 25)
        Me.lblSales.TabIndex = 3
        Me.lblSales.Text = "Sales"
        '
        'lblProduct
        '
        Me.lblProduct.AutoSize = True
        Me.lblProduct.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduct.ForeColor = System.Drawing.Color.White
        Me.lblProduct.Location = New System.Drawing.Point(39, 431)
        Me.lblProduct.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProduct.Name = "lblProduct"
        Me.lblProduct.Size = New System.Drawing.Size(89, 25)
        Me.lblProduct.TabIndex = 2
        Me.lblProduct.Text = "Products"
        '
        'lblDashboard
        '
        Me.lblDashboard.AutoSize = True
        Me.lblDashboard.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDashboard.ForeColor = System.Drawing.Color.White
        Me.lblDashboard.Location = New System.Drawing.Point(28, 363)
        Me.lblDashboard.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDashboard.Name = "lblDashboard"
        Me.lblDashboard.Size = New System.Drawing.Size(108, 25)
        Me.lblDashboard.TabIndex = 1
        Me.lblDashboard.Text = "Dashboard"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources.user
        Me.PictureBox1.Location = New System.Drawing.Point(34, 37)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(105, 108)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.Black
        Me.lblTitle.Location = New System.Drawing.Point(198, 29)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(193, 40)
        Me.lblTitle.TabIndex = 6
        Me.lblTitle.Text = "Dashboard"
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.BorderRadius = 10
        Me.Guna2Elipse1.TargetControl = Me.Label10
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(82, 37)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(206, 195)
        Me.Label10.TabIndex = 10
        '
        'Guna2Elipse2
        '
        Me.Guna2Elipse2.TargetControl = Me.Label13
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Red
        Me.Label13.Location = New System.Drawing.Point(384, 37)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(206, 195)
        Me.Label13.TabIndex = 13
        '
        'Guna2Elipse3
        '
        Me.Guna2Elipse3.TargetControl = Me.Label16
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(684, 37)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(206, 195)
        Me.Label16.TabIndex = 16
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'TabPage4
        '
        Me.TabPage4.AutoScroll = True
        Me.TabPage4.BackColor = System.Drawing.Color.White
        Me.TabPage4.Controls.Add(Me.pnlSaleschkOut)
        Me.TabPage4.Controls.Add(Me.Panel5)
        Me.TabPage4.Controls.Add(Me.pnlPayment)
        Me.TabPage4.Controls.Add(Me.Label1)
        Me.TabPage4.Controls.Add(Me.Panel6)
        Me.TabPage4.Location = New System.Drawing.Point(4, 5)
        Me.TabPage4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage4.Size = New System.Drawing.Size(1342, 982)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "TabPage4"
        '
        'pnlSaleschkOut
        '
        Me.pnlSaleschkOut.Controls.Add(Me.lblRemove)
        Me.pnlSaleschkOut.Controls.Add(Me.lblNum)
        Me.pnlSaleschkOut.Controls.Add(Me.lblQuantity)
        Me.pnlSaleschkOut.Controls.Add(Me.lblPlus)
        Me.pnlSaleschkOut.Controls.Add(Me.lblMinus)
        Me.pnlSaleschkOut.Controls.Add(Me.lblSPrice)
        Me.pnlSaleschkOut.Controls.Add(Me.lblSName)
        Me.pnlSaleschkOut.Controls.Add(Me.picSales)
        Me.pnlSaleschkOut.Location = New System.Drawing.Point(50, 618)
        Me.pnlSaleschkOut.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.pnlSaleschkOut.Name = "pnlSaleschkOut"
        Me.pnlSaleschkOut.Size = New System.Drawing.Size(290, 162)
        Me.pnlSaleschkOut.TabIndex = 1
        Me.pnlSaleschkOut.Visible = False
        '
        'lblRemove
        '
        Me.lblRemove.AutoSize = True
        Me.lblRemove.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRemove.ForeColor = System.Drawing.Color.Red
        Me.lblRemove.Location = New System.Drawing.Point(246, 12)
        Me.lblRemove.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblRemove.Name = "lblRemove"
        Me.lblRemove.Size = New System.Drawing.Size(24, 29)
        Me.lblRemove.TabIndex = 8
        Me.lblRemove.Text = "x"
        '
        'lblNum
        '
        Me.lblNum.AutoSize = True
        Me.lblNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNum.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblNum.Location = New System.Drawing.Point(166, 106)
        Me.lblNum.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblNum.Name = "lblNum"
        Me.lblNum.Size = New System.Drawing.Size(23, 25)
        Me.lblNum.TabIndex = 7
        Me.lblNum.Text = "1"
        '
        'lblQuantity
        '
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblQuantity.Location = New System.Drawing.Point(126, 78)
        Me.lblQuantity.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(51, 15)
        Me.lblQuantity.TabIndex = 6
        Me.lblQuantity.Text = "Quantity"
        '
        'lblPlus
        '
        Me.lblPlus.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlus.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPlus.Location = New System.Drawing.Point(220, 95)
        Me.lblPlus.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPlus.Name = "lblPlus"
        Me.lblPlus.Size = New System.Drawing.Size(40, 37)
        Me.lblPlus.TabIndex = 4
        Me.lblPlus.Text = "+"
        '
        'lblMinus
        '
        Me.lblMinus.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMinus.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblMinus.Location = New System.Drawing.Point(116, 95)
        Me.lblMinus.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMinus.Name = "lblMinus"
        Me.lblMinus.Size = New System.Drawing.Size(28, 37)
        Me.lblMinus.TabIndex = 5
        Me.lblMinus.Text = "-"
        '
        'lblSPrice
        '
        Me.lblSPrice.AutoSize = True
        Me.lblSPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSPrice.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblSPrice.Location = New System.Drawing.Point(118, 54)
        Me.lblSPrice.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSPrice.Name = "lblSPrice"
        Me.lblSPrice.Size = New System.Drawing.Size(60, 18)
        Me.lblSPrice.TabIndex = 3
        Me.lblSPrice.Text = "1299.00"
        '
        'lblSName
        '
        Me.lblSName.AutoSize = True
        Me.lblSName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblSName.Location = New System.Drawing.Point(117, 23)
        Me.lblSName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSName.Name = "lblSName"
        Me.lblSName.Size = New System.Drawing.Size(96, 25)
        Me.lblSName.TabIndex = 2
        Me.lblSName.Text = "Polo Shirt"
        '
        'picSales
        '
        Me.picSales.Image = Global.WindowsApplication1.My.Resources.Resources.s
        Me.picSales.Location = New System.Drawing.Point(14, 37)
        Me.picSales.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.picSales.Name = "picSales"
        Me.picSales.Size = New System.Drawing.Size(88, 86)
        Me.picSales.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSales.TabIndex = 0
        Me.picSales.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.AutoScroll = True
        Me.Panel5.BackColor = System.Drawing.Color.Silver
        Me.Panel5.Controls.Add(Me.Panel7)
        Me.Panel5.Controls.Add(Me.lblTotals)
        Me.Panel5.Controls.Add(Me.btnComplete)
        Me.Panel5.Controls.Add(Me.Label30)
        Me.Panel5.Controls.Add(Me.lblClose)
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel5.Location = New System.Drawing.Point(1308, 5)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(362, 946)
        Me.Panel5.TabIndex = 4
        Me.Panel5.Visible = False
        '
        'Panel7
        '
        Me.Panel7.AutoScroll = True
        Me.Panel7.Controls.Add(Me.TableLayoutPanel3)
        Me.Panel7.Location = New System.Drawing.Point(0, 95)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(357, 537)
        Me.Panel7.TabIndex = 11
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.AutoScroll = True
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 357.0!))
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(357, 466)
        Me.TableLayoutPanel3.TabIndex = 2
        '
        'lblTotals
        '
        Me.lblTotals.AutoSize = True
        Me.lblTotals.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotals.ForeColor = System.Drawing.Color.DarkGreen
        Me.lblTotals.Location = New System.Drawing.Point(105, 674)
        Me.lblTotals.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTotals.Name = "lblTotals"
        Me.lblTotals.Size = New System.Drawing.Size(71, 22)
        Me.lblTotals.TabIndex = 10
        Me.lblTotals.Text = "123.00"
        '
        'btnComplete
        '
        Me.btnComplete.BorderRadius = 10
        Me.btnComplete.CheckedState.Parent = Me.btnComplete
        Me.btnComplete.CustomImages.Parent = Me.btnComplete
        Me.btnComplete.FillColor = System.Drawing.Color.Red
        Me.btnComplete.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnComplete.ForeColor = System.Drawing.Color.White
        Me.btnComplete.HoverState.Parent = Me.btnComplete
        Me.btnComplete.Location = New System.Drawing.Point(33, 731)
        Me.btnComplete.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnComplete.Name = "btnComplete"
        Me.btnComplete.ShadowDecoration.Parent = Me.btnComplete
        Me.btnComplete.Size = New System.Drawing.Size(300, 69)
        Me.btnComplete.TabIndex = 9
        Me.btnComplete.Text = "Buy Sales"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(36, 672)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(68, 25)
        Me.Label30.TabIndex = 9
        Me.Label30.Text = "Total:"
        '
        'lblClose
        '
        Me.lblClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblClose.Location = New System.Drawing.Point(292, 31)
        Me.lblClose.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblClose.Name = "lblClose"
        Me.lblClose.Size = New System.Drawing.Size(40, 37)
        Me.lblClose.TabIndex = 8
        Me.lblClose.Text = "x"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(20, 31)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(191, 33)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Add to Sales"
        '
        'pnlPayment
        '
        Me.pnlPayment.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pnlPayment.BorderRadius = 30
        Me.pnlPayment.BorderThickness = 1
        Me.pnlPayment.Controls.Add(Me.btnPayment)
        Me.pnlPayment.Controls.Add(Me.lblTotal)
        Me.pnlPayment.Controls.Add(Me.Label27)
        Me.pnlPayment.Controls.Add(Me.TableLayoutPanel4)
        Me.pnlPayment.Controls.Add(Me.Label5)
        Me.pnlPayment.Controls.Add(Me.Label26)
        Me.pnlPayment.Controls.Add(Me.Label6)
        Me.pnlPayment.Controls.Add(Me.Label4)
        Me.pnlPayment.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pnlPayment.Location = New System.Drawing.Point(432, 55)
        Me.pnlPayment.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.pnlPayment.Name = "pnlPayment"
        Me.pnlPayment.ShadowDecoration.Parent = Me.pnlPayment
        Me.pnlPayment.Size = New System.Drawing.Size(418, 554)
        Me.pnlPayment.TabIndex = 3
        Me.pnlPayment.Visible = False
        '
        'btnPayment
        '
        Me.btnPayment.CheckedState.Parent = Me.btnPayment
        Me.btnPayment.CustomImages.Parent = Me.btnPayment
        Me.btnPayment.FillColor = System.Drawing.Color.Red
        Me.btnPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPayment.ForeColor = System.Drawing.Color.White
        Me.btnPayment.HoverState.Parent = Me.btnPayment
        Me.btnPayment.Location = New System.Drawing.Point(123, 455)
        Me.btnPayment.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnPayment.Name = "btnPayment"
        Me.btnPayment.ShadowDecoration.Parent = Me.btnPayment
        Me.btnPayment.Size = New System.Drawing.Size(225, 55)
        Me.btnPayment.TabIndex = 8
        Me.btnPayment.Text = "Thank You"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(117, 420)
        Me.lblTotal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(78, 25)
        Me.lblTotal.TabIndex = 7
        Me.lblTotal.Text = "123.00"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(36, 420)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(68, 25)
        Me.Label27.TabIndex = 6
        Me.Label27.Text = "Total:"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.lblProdName, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lblPQuanity, 1, 0)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(42, 154)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 2
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(312, 122)
        Me.TableLayoutPanel4.TabIndex = 5
        '
        'lblProdName
        '
        Me.lblProdName.AutoSize = True
        Me.lblProdName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProdName.Location = New System.Drawing.Point(4, 0)
        Me.lblProdName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProdName.Name = "lblProdName"
        Me.lblProdName.Size = New System.Drawing.Size(136, 22)
        Me.lblProdName.TabIndex = 6
        Me.lblProdName.Text = "Product Name"
        Me.lblProdName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPQuanity
        '
        Me.lblPQuanity.AutoSize = True
        Me.lblPQuanity.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPQuanity.Location = New System.Drawing.Point(160, 0)
        Me.lblPQuanity.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPQuanity.Name = "lblPQuanity"
        Me.lblPQuanity.Size = New System.Drawing.Size(85, 22)
        Me.lblPQuanity.TabIndex = 6
        Me.lblPQuanity.Text = "Quantity"
        Me.lblPQuanity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(158, 263)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 22)
        Me.Label5.TabIndex = 4
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(228, 112)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(85, 22)
        Me.Label26.TabIndex = 3
        Me.Label26.Text = "Quantity"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(38, 112)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 22)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Product Name"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(33, 29)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(224, 37)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Sales Reciept"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(45, 35)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 33)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "All Sales"
        '
        'Panel6
        '
        Me.Panel6.AutoScroll = True
        Me.Panel6.Controls.Add(Me.Panel4)
        Me.Panel6.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel6.Location = New System.Drawing.Point(50, 100)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1262, 731)
        Me.Panel6.TabIndex = 5
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.txtSPrice)
        Me.Panel4.Controls.Add(Me.txtSName)
        Me.Panel4.Controls.Add(Me.btnAddSales)
        Me.Panel4.Controls.Add(Me.picSale)
        Me.Panel4.Location = New System.Drawing.Point(298, 518)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(250, 394)
        Me.Panel4.TabIndex = 2
        Me.Panel4.Visible = False
        '
        'txtSPrice
        '
        Me.txtSPrice.AutoSize = True
        Me.txtSPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSPrice.Location = New System.Drawing.Point(27, 262)
        Me.txtSPrice.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtSPrice.Name = "txtSPrice"
        Me.txtSPrice.Size = New System.Drawing.Size(75, 22)
        Me.txtSPrice.TabIndex = 3
        Me.txtSPrice.Text = "1999.00"
        '
        'txtSName
        '
        Me.txtSName.AutoSize = True
        Me.txtSName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSName.Location = New System.Drawing.Point(27, 220)
        Me.txtSName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtSName.Name = "txtSName"
        Me.txtSName.Size = New System.Drawing.Size(183, 29)
        Me.txtSName.TabIndex = 2
        Me.txtSName.Text = "T-Shirt Summer"
        '
        'btnAddSales
        '
        Me.btnAddSales.BackColor = System.Drawing.Color.Firebrick
        Me.btnAddSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAddSales.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddSales.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnAddSales.Location = New System.Drawing.Point(24, 308)
        Me.btnAddSales.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnAddSales.Name = "btnAddSales"
        Me.btnAddSales.Size = New System.Drawing.Size(202, 46)
        Me.btnAddSales.TabIndex = 1
        Me.btnAddSales.Text = "Add to Sale"
        Me.btnAddSales.UseVisualStyleBackColor = False
        '
        'picSale
        '
        Me.picSale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picSale.Image = Global.WindowsApplication1.My.Resources.Resources.s
        Me.picSale.Location = New System.Drawing.Point(24, 23)
        Me.picSale.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.picSale.Name = "picSale"
        Me.picSale.Size = New System.Drawing.Size(202, 174)
        Me.picSale.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSale.TabIndex = 0
        Me.picSale.TabStop = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.AutoScroll = True
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(4, 26)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 445.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1160, 445)
        Me.TableLayoutPanel2.TabIndex = 3
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.Controls.Add(Me.txtPrice)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Controls.Add(Me.btnQrBar)
        Me.TabPage3.Controls.Add(Me.btnDelete)
        Me.TabPage3.Controls.Add(Me.btnUpload)
        Me.TabPage3.Controls.Add(Me.btnCancel)
        Me.TabPage3.Controls.Add(Me.btnAddProd)
        Me.TabPage3.Controls.Add(Me.chkXXXL)
        Me.TabPage3.Controls.Add(Me.chkXXL)
        Me.TabPage3.Controls.Add(Me.chkXL)
        Me.TabPage3.Controls.Add(Me.chkL)
        Me.TabPage3.Controls.Add(Me.chkM)
        Me.TabPage3.Controls.Add(Me.chkS)
        Me.TabPage3.Controls.Add(Me.Label25)
        Me.TabPage3.Controls.Add(Me.ChkDress)
        Me.TabPage3.Controls.Add(Me.ChkPants)
        Me.TabPage3.Controls.Add(Me.ChkSweather)
        Me.TabPage3.Controls.Add(Me.ChkTshirt)
        Me.TabPage3.Controls.Add(Me.ChkPolo)
        Me.TabPage3.Controls.Add(Me.ChkHoodie)
        Me.TabPage3.Controls.Add(Me.Label24)
        Me.TabPage3.Controls.Add(Me.txtStock)
        Me.TabPage3.Controls.Add(Me.Label23)
        Me.TabPage3.Controls.Add(Me.txtColor)
        Me.TabPage3.Controls.Add(Me.Label22)
        Me.TabPage3.Controls.Add(Me.txtProdName)
        Me.TabPage3.Controls.Add(Me.Label21)
        Me.TabPage3.Controls.Add(Me.ShapeContainer1)
        Me.TabPage3.Controls.Add(Me.picQRBAR)
        Me.TabPage3.Controls.Add(Me.picProd)
        Me.TabPage3.Location = New System.Drawing.Point(4, 5)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage3.Size = New System.Drawing.Size(1342, 982)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "TabPage3"
        '
        'txtPrice
        '
        Me.txtPrice.BackColor = System.Drawing.Color.White
        Me.txtPrice.BorderColor = System.Drawing.Color.White
        Me.txtPrice.BorderThickness = 0
        Me.txtPrice.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPrice.DefaultText = ""
        Me.txtPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPrice.DisabledState.Parent = Me.txtPrice
        Me.txtPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPrice.FocusedState.Parent = Me.txtPrice
        Me.txtPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice.ForeColor = System.Drawing.Color.Black
        Me.txtPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPrice.HoverState.Parent = Me.txtPrice
        Me.txtPrice.Location = New System.Drawing.Point(990, 558)
        Me.txtPrice.Margin = New System.Windows.Forms.Padding(8, 9, 8, 9)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtPrice.PlaceholderText = ""
        Me.txtPrice.SelectedText = ""
        Me.txtPrice.ShadowDecoration.Parent = Me.txtPrice
        Me.txtPrice.Size = New System.Drawing.Size(220, 38)
        Me.txtPrice.TabIndex = 29
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(980, 482)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 20)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Price"
        '
        'btnQrBar
        '
        Me.btnQrBar.CheckedState.Parent = Me.btnQrBar
        Me.btnQrBar.CustomImages.Parent = Me.btnQrBar
        Me.btnQrBar.FillColor = System.Drawing.Color.Red
        Me.btnQrBar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQrBar.ForeColor = System.Drawing.Color.White
        Me.btnQrBar.HoverState.Parent = Me.btnQrBar
        Me.btnQrBar.Location = New System.Drawing.Point(1023, 358)
        Me.btnQrBar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnQrBar.Name = "btnQrBar"
        Me.btnQrBar.ShadowDecoration.Parent = Me.btnQrBar
        Me.btnQrBar.Size = New System.Drawing.Size(244, 66)
        Me.btnQrBar.TabIndex = 27
        Me.btnQrBar.Text = "Qr Code"
        '
        'btnDelete
        '
        Me.btnDelete.BorderColor = System.Drawing.Color.Red
        Me.btnDelete.BorderRadius = 10
        Me.btnDelete.BorderThickness = 1
        Me.btnDelete.CheckedState.Parent = Me.btnDelete
        Me.btnDelete.CustomImages.Parent = Me.btnDelete
        Me.btnDelete.FillColor = System.Drawing.Color.White
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnDelete.ForeColor = System.Drawing.Color.Black
        Me.btnDelete.HoverState.Parent = Me.btnDelete
        Me.btnDelete.Location = New System.Drawing.Point(582, 698)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.ShadowDecoration.Parent = Me.btnDelete
        Me.btnDelete.Size = New System.Drawing.Size(172, 62)
        Me.btnDelete.TabIndex = 25
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.Visible = False
        '
        'btnUpload
        '
        Me.btnUpload.BorderColor = System.Drawing.Color.Red
        Me.btnUpload.BorderRadius = 10
        Me.btnUpload.BorderThickness = 1
        Me.btnUpload.CheckedState.Parent = Me.btnUpload
        Me.btnUpload.CustomImages.Parent = Me.btnUpload
        Me.btnUpload.FillColor = System.Drawing.Color.White
        Me.btnUpload.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnUpload.ForeColor = System.Drawing.Color.Black
        Me.btnUpload.HoverState.Parent = Me.btnUpload
        Me.btnUpload.Location = New System.Drawing.Point(54, 289)
        Me.btnUpload.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.ShadowDecoration.Parent = Me.btnUpload
        Me.btnUpload.Size = New System.Drawing.Size(172, 62)
        Me.btnUpload.TabIndex = 24
        Me.btnUpload.Text = "Upload Img"
        '
        'btnCancel
        '
        Me.btnCancel.BorderColor = System.Drawing.Color.Red
        Me.btnCancel.BorderRadius = 10
        Me.btnCancel.BorderThickness = 1
        Me.btnCancel.CheckedState.Parent = Me.btnCancel
        Me.btnCancel.CustomImages.Parent = Me.btnCancel
        Me.btnCancel.FillColor = System.Drawing.Color.White
        Me.btnCancel.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Black
        Me.btnCancel.HoverState.Parent = Me.btnCancel
        Me.btnCancel.Location = New System.Drawing.Point(786, 698)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.ShadowDecoration.Parent = Me.btnCancel
        Me.btnCancel.Size = New System.Drawing.Size(172, 62)
        Me.btnCancel.TabIndex = 22
        Me.btnCancel.Text = "Cancel"
        '
        'btnAddProd
        '
        Me.btnAddProd.BorderColor = System.Drawing.Color.Red
        Me.btnAddProd.BorderRadius = 10
        Me.btnAddProd.BorderThickness = 1
        Me.btnAddProd.CheckedState.Parent = Me.btnAddProd
        Me.btnAddProd.CustomImages.Parent = Me.btnAddProd
        Me.btnAddProd.FillColor = System.Drawing.Color.White
        Me.btnAddProd.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnAddProd.ForeColor = System.Drawing.Color.Black
        Me.btnAddProd.HoverState.Parent = Me.btnAddProd
        Me.btnAddProd.Location = New System.Drawing.Point(998, 698)
        Me.btnAddProd.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnAddProd.Name = "btnAddProd"
        Me.btnAddProd.ShadowDecoration.Parent = Me.btnAddProd
        Me.btnAddProd.Size = New System.Drawing.Size(224, 62)
        Me.btnAddProd.TabIndex = 21
        Me.btnAddProd.Text = "Add Product"
        '
        'chkXXXL
        '
        Me.chkXXXL.BackColor = System.Drawing.Color.White
        Me.chkXXXL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkXXXL.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkXXXL.Location = New System.Drawing.Point(862, 558)
        Me.chkXXXL.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkXXXL.Name = "chkXXXL"
        Me.chkXXXL.Size = New System.Drawing.Size(98, 54)
        Me.chkXXXL.TabIndex = 20
        Me.chkXXXL.Text = "XXXL"
        Me.chkXXXL.UseVisualStyleBackColor = False
        '
        'chkXXL
        '
        Me.chkXXL.BackColor = System.Drawing.Color.White
        Me.chkXXL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkXXL.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkXXL.Location = New System.Drawing.Point(741, 560)
        Me.chkXXL.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkXXL.Name = "chkXXL"
        Me.chkXXL.Size = New System.Drawing.Size(98, 54)
        Me.chkXXL.TabIndex = 19
        Me.chkXXL.Text = "XXL"
        Me.chkXXL.UseVisualStyleBackColor = False
        '
        'chkXL
        '
        Me.chkXL.BackColor = System.Drawing.Color.White
        Me.chkXL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkXL.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkXL.Location = New System.Drawing.Point(634, 560)
        Me.chkXL.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkXL.Name = "chkXL"
        Me.chkXL.Size = New System.Drawing.Size(98, 54)
        Me.chkXL.TabIndex = 18
        Me.chkXL.Text = "XL"
        Me.chkXL.UseVisualStyleBackColor = False
        '
        'chkL
        '
        Me.chkL.BackColor = System.Drawing.Color.White
        Me.chkL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkL.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkL.Location = New System.Drawing.Point(861, 480)
        Me.chkL.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkL.Name = "chkL"
        Me.chkL.Size = New System.Drawing.Size(98, 54)
        Me.chkL.TabIndex = 17
        Me.chkL.Text = "L"
        Me.chkL.UseVisualStyleBackColor = False
        '
        'chkM
        '
        Me.chkM.BackColor = System.Drawing.Color.White
        Me.chkM.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkM.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkM.Location = New System.Drawing.Point(741, 480)
        Me.chkM.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkM.Name = "chkM"
        Me.chkM.Size = New System.Drawing.Size(98, 54)
        Me.chkM.TabIndex = 16
        Me.chkM.Text = "M"
        Me.chkM.UseVisualStyleBackColor = False
        '
        'chkS
        '
        Me.chkS.BackColor = System.Drawing.Color.White
        Me.chkS.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkS.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkS.Location = New System.Drawing.Point(634, 480)
        Me.chkS.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkS.Name = "chkS"
        Me.chkS.Size = New System.Drawing.Size(98, 54)
        Me.chkS.TabIndex = 15
        Me.chkS.Text = "S"
        Me.chkS.UseVisualStyleBackColor = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(628, 445)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(51, 25)
        Me.Label25.TabIndex = 14
        Me.Label25.Text = "Size"
        '
        'ChkDress
        '
        Me.ChkDress.Appearance = System.Windows.Forms.Appearance.Button
        Me.ChkDress.AutoEllipsis = True
        Me.ChkDress.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ChkDress.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkDress.Location = New System.Drawing.Point(291, 682)
        Me.ChkDress.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ChkDress.Name = "ChkDress"
        Me.ChkDress.Size = New System.Drawing.Size(207, 54)
        Me.ChkDress.TabIndex = 13
        Me.ChkDress.Text = "Dress"
        Me.ChkDress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ChkDress.UseVisualStyleBackColor = True
        '
        'ChkPants
        '
        Me.ChkPants.Appearance = System.Windows.Forms.Appearance.Button
        Me.ChkPants.AutoEllipsis = True
        Me.ChkPants.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ChkPants.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkPants.Location = New System.Drawing.Point(54, 682)
        Me.ChkPants.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ChkPants.Name = "ChkPants"
        Me.ChkPants.Size = New System.Drawing.Size(207, 54)
        Me.ChkPants.TabIndex = 12
        Me.ChkPants.Text = "Pants"
        Me.ChkPants.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ChkPants.UseVisualStyleBackColor = True
        '
        'ChkSweather
        '
        Me.ChkSweather.Appearance = System.Windows.Forms.Appearance.Button
        Me.ChkSweather.AutoEllipsis = True
        Me.ChkSweather.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ChkSweather.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkSweather.Location = New System.Drawing.Point(291, 585)
        Me.ChkSweather.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ChkSweather.Name = "ChkSweather"
        Me.ChkSweather.Size = New System.Drawing.Size(207, 54)
        Me.ChkSweather.TabIndex = 11
        Me.ChkSweather.Text = "Sweather"
        Me.ChkSweather.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ChkSweather.UseVisualStyleBackColor = True
        '
        'ChkTshirt
        '
        Me.ChkTshirt.Appearance = System.Windows.Forms.Appearance.Button
        Me.ChkTshirt.AutoEllipsis = True
        Me.ChkTshirt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ChkTshirt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkTshirt.Location = New System.Drawing.Point(52, 585)
        Me.ChkTshirt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ChkTshirt.Name = "ChkTshirt"
        Me.ChkTshirt.Size = New System.Drawing.Size(207, 54)
        Me.ChkTshirt.TabIndex = 10
        Me.ChkTshirt.Text = "T-Shirt"
        Me.ChkTshirt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ChkTshirt.UseVisualStyleBackColor = True
        '
        'ChkPolo
        '
        Me.ChkPolo.Appearance = System.Windows.Forms.Appearance.Button
        Me.ChkPolo.AutoEllipsis = True
        Me.ChkPolo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ChkPolo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkPolo.Location = New System.Drawing.Point(291, 488)
        Me.ChkPolo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ChkPolo.Name = "ChkPolo"
        Me.ChkPolo.Size = New System.Drawing.Size(207, 54)
        Me.ChkPolo.TabIndex = 9
        Me.ChkPolo.Text = "Polo/. Polo Shirt"
        Me.ChkPolo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ChkPolo.UseVisualStyleBackColor = True
        '
        'ChkHoodie
        '
        Me.ChkHoodie.Appearance = System.Windows.Forms.Appearance.Button
        Me.ChkHoodie.AutoEllipsis = True
        Me.ChkHoodie.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ChkHoodie.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkHoodie.Location = New System.Drawing.Point(52, 488)
        Me.ChkHoodie.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ChkHoodie.Name = "ChkHoodie"
        Me.ChkHoodie.Size = New System.Drawing.Size(200, 54)
        Me.ChkHoodie.TabIndex = 8
        Me.ChkHoodie.Text = "Jacket/ Hoodie"
        Me.ChkHoodie.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ChkHoodie.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(48, 431)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(107, 25)
        Me.Label24.TabIndex = 7
        Me.Label24.Text = "Categories"
        '
        'txtStock
        '
        Me.txtStock.BackColor = System.Drawing.Color.White
        Me.txtStock.BorderColor = System.Drawing.Color.White
        Me.txtStock.BorderThickness = 0
        Me.txtStock.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtStock.DefaultText = ""
        Me.txtStock.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtStock.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtStock.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtStock.DisabledState.Parent = Me.txtStock
        Me.txtStock.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtStock.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtStock.FocusedState.Parent = Me.txtStock
        Me.txtStock.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStock.ForeColor = System.Drawing.Color.Black
        Me.txtStock.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtStock.HoverState.Parent = Me.txtStock
        Me.txtStock.Location = New System.Drawing.Point(658, 331)
        Me.txtStock.Margin = New System.Windows.Forms.Padding(8, 9, 8, 9)
        Me.txtStock.Name = "txtStock"
        Me.txtStock.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtStock.PlaceholderText = ""
        Me.txtStock.SelectedText = ""
        Me.txtStock.ShadowDecoration.Parent = Me.txtStock
        Me.txtStock.Size = New System.Drawing.Size(315, 38)
        Me.txtStock.TabIndex = 6
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(654, 254)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(51, 20)
        Me.Label23.TabIndex = 5
        Me.Label23.Text = "Stock"
        '
        'txtColor
        '
        Me.txtColor.BackColor = System.Drawing.Color.White
        Me.txtColor.BorderColor = System.Drawing.Color.White
        Me.txtColor.BorderThickness = 0
        Me.txtColor.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtColor.DefaultText = ""
        Me.txtColor.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtColor.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtColor.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtColor.DisabledState.Parent = Me.txtColor
        Me.txtColor.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtColor.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtColor.FocusedState.Parent = Me.txtColor
        Me.txtColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtColor.ForeColor = System.Drawing.Color.Black
        Me.txtColor.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtColor.HoverState.Parent = Me.txtColor
        Me.txtColor.Location = New System.Drawing.Point(303, 331)
        Me.txtColor.Margin = New System.Windows.Forms.Padding(8, 9, 8, 9)
        Me.txtColor.Name = "txtColor"
        Me.txtColor.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtColor.PlaceholderText = ""
        Me.txtColor.SelectedText = ""
        Me.txtColor.ShadowDecoration.Parent = Me.txtColor
        Me.txtColor.Size = New System.Drawing.Size(315, 38)
        Me.txtColor.TabIndex = 4
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(306, 254)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(49, 20)
        Me.Label22.TabIndex = 3
        Me.Label22.Text = "Color"
        '
        'txtProdName
        '
        Me.txtProdName.BackColor = System.Drawing.Color.White
        Me.txtProdName.BorderColor = System.Drawing.Color.White
        Me.txtProdName.BorderThickness = 0
        Me.txtProdName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProdName.DefaultText = ""
        Me.txtProdName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtProdName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtProdName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtProdName.DisabledState.Parent = Me.txtProdName
        Me.txtProdName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtProdName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtProdName.FocusedState.Parent = Me.txtProdName
        Me.txtProdName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProdName.ForeColor = System.Drawing.Color.Black
        Me.txtProdName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtProdName.HoverState.Parent = Me.txtProdName
        Me.txtProdName.Location = New System.Drawing.Point(300, 118)
        Me.txtProdName.Margin = New System.Windows.Forms.Padding(8, 9, 8, 9)
        Me.txtProdName.Name = "txtProdName"
        Me.txtProdName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtProdName.PlaceholderText = ""
        Me.txtProdName.SelectedText = ""
        Me.txtProdName.ShadowDecoration.Parent = Me.txtProdName
        Me.txtProdName.Size = New System.Drawing.Size(674, 54)
        Me.txtProdName.TabIndex = 2
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(297, 57)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(116, 20)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Product Name"
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(4, 5)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape4, Me.LineShape3, Me.LineShape2, Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(1334, 972)
        Me.ShapeContainer1.TabIndex = 23
        Me.ShapeContainer1.TabStop = False
        '
        'LineShape4
        '
        Me.LineShape4.Name = "LineShape4"
        Me.LineShape4.X1 = 655
        Me.LineShape4.X2 = 803
        Me.LineShape4.Y1 = 395
        Me.LineShape4.Y2 = 395
        '
        'LineShape3
        '
        Me.LineShape3.Name = "LineShape3"
        Me.LineShape3.X1 = 434
        Me.LineShape3.X2 = 649
        Me.LineShape3.Y1 = 244
        Me.LineShape3.Y2 = 243
        '
        'LineShape2
        '
        Me.LineShape2.Name = "LineShape2"
        Me.LineShape2.X1 = 198
        Me.LineShape2.X2 = 413
        Me.LineShape2.Y1 = 245
        Me.LineShape2.Y2 = 244
        '
        'LineShape1
        '
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 198
        Me.LineShape1.X2 = 647
        Me.LineShape1.Y1 = 116
        Me.LineShape1.Y2 = 116
        '
        'picQRBAR
        '
        Me.picQRBAR.Location = New System.Drawing.Point(1023, 57)
        Me.picQRBAR.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.picQRBAR.Name = "picQRBAR"
        Me.picQRBAR.Size = New System.Drawing.Size(238, 275)
        Me.picQRBAR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picQRBAR.TabIndex = 26
        Me.picQRBAR.TabStop = False
        '
        'picProd
        '
        Me.picProd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picProd.Location = New System.Drawing.Point(54, 57)
        Me.picProd.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.picProd.Name = "picProd"
        Me.picProd.Size = New System.Drawing.Size(185, 222)
        Me.picProd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picProd.TabIndex = 0
        Me.picProd.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.Controls.Add(Me.cmbFilter)
        Me.TabPage2.Controls.Add(Me.Panel3)
        Me.TabPage2.Controls.Add(Me.TableLayoutPanel1)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.Guna2Button2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 5)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage2.Size = New System.Drawing.Size(1342, 982)
        Me.TabPage2.TabIndex = 1
        '
        'cmbFilter
        '
        Me.cmbFilter.FormattingEnabled = True
        Me.cmbFilter.Items.AddRange(New Object() {"₱100 – ₱500  ", "₱500 – ₱1,000  ", "₱1,000 – ₱5,000  ", "₱5,000 – ₱10,000  ", "₱10,000 – ₱20,000  ", "₱20,000 and above"})
        Me.cmbFilter.Location = New System.Drawing.Point(1012, 52)
        Me.cmbFilter.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbFilter.Name = "cmbFilter"
        Me.cmbFilter.Size = New System.Drawing.Size(205, 28)
        Me.cmbFilter.TabIndex = 14
        Me.cmbFilter.Text = "Price Filter"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnViewStock2)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.PictureBox4)
        Me.Panel3.Location = New System.Drawing.Point(422, 428)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(315, 372)
        Me.Panel3.TabIndex = 3
        Me.Panel3.Visible = False
        '
        'btnViewStock2
        '
        Me.btnViewStock2.BorderColor = System.Drawing.Color.Red
        Me.btnViewStock2.BorderRadius = 5
        Me.btnViewStock2.BorderThickness = 1
        Me.btnViewStock2.CheckedState.Parent = Me.btnViewStock2
        Me.btnViewStock2.CustomImages.Parent = Me.btnViewStock2
        Me.btnViewStock2.FillColor = System.Drawing.Color.White
        Me.btnViewStock2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewStock2.ForeColor = System.Drawing.Color.Black
        Me.btnViewStock2.HoverState.Parent = Me.btnViewStock2
        Me.btnViewStock2.Location = New System.Drawing.Point(134, 292)
        Me.btnViewStock2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnViewStock2.Name = "btnViewStock2"
        Me.btnViewStock2.ShadowDecoration.Parent = Me.btnViewStock2
        Me.btnViewStock2.Size = New System.Drawing.Size(158, 51)
        Me.btnViewStock2.TabIndex = 2
        Me.btnViewStock2.Text = "View Stock"
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(33, 225)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(219, 57)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Dry Non Iron Jersey Short Sleeve Shirt"
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.WindowsApplication1.My.Resources.Resources.s
        Me.PictureBox4.Location = New System.Drawing.Point(34, 20)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(172, 192)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 0
        Me.PictureBox4.TabStop = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 2, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(27, 137)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 685.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 685.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1230, 685)
        Me.TableLayoutPanel1.TabIndex = 13
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblPrice)
        Me.Panel2.Controls.Add(Me.btnViewStock)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.PictureBox3)
        Me.Panel2.Location = New System.Drawing.Point(823, 5)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(315, 415)
        Me.Panel2.TabIndex = 0
        Me.Panel2.Visible = False
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice.Location = New System.Drawing.Point(33, 288)
        Me.lblPrice.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(94, 20)
        Me.lblPrice.TabIndex = 3
        Me.lblPrice.Text = "Price: 1293"
        '
        'btnViewStock
        '
        Me.btnViewStock.BorderColor = System.Drawing.Color.Red
        Me.btnViewStock.BorderRadius = 5
        Me.btnViewStock.BorderThickness = 1
        Me.btnViewStock.CheckedState.Parent = Me.btnViewStock
        Me.btnViewStock.CustomImages.Parent = Me.btnViewStock
        Me.btnViewStock.FillColor = System.Drawing.Color.White
        Me.btnViewStock.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewStock.ForeColor = System.Drawing.Color.Black
        Me.btnViewStock.HoverState.Parent = Me.btnViewStock
        Me.btnViewStock.Location = New System.Drawing.Point(134, 334)
        Me.btnViewStock.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnViewStock.Name = "btnViewStock"
        Me.btnViewStock.ShadowDecoration.Parent = Me.btnViewStock
        Me.btnViewStock.Size = New System.Drawing.Size(158, 51)
        Me.btnViewStock.TabIndex = 2
        Me.btnViewStock.Text = "View Stock"
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(33, 225)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(219, 57)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "Dry Non Iron Jersey Short Sleeve Shirt"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.WindowsApplication1.My.Resources.Resources.s
        Me.PictureBox3.Location = New System.Drawing.Point(34, 20)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(172, 192)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(940, 49)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(54, 25)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Filter"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(20, 35)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(144, 33)
        Me.Label18.TabIndex = 9
        Me.Label18.Text = "All Stocks"
        '
        'Guna2Button2
        '
        Me.Guna2Button2.BorderColor = System.Drawing.Color.Red
        Me.Guna2Button2.BorderRadius = 5
        Me.Guna2Button2.BorderThickness = 1
        Me.Guna2Button2.CheckedState.Parent = Me.Guna2Button2
        Me.Guna2Button2.CustomImages.Parent = Me.Guna2Button2
        Me.Guna2Button2.FillColor = System.Drawing.Color.Red
        Me.Guna2Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Guna2Button2.HoverState.Parent = Me.Guna2Button2
        Me.Guna2Button2.Image = Global.WindowsApplication1.My.Resources.Resources.se
        Me.Guna2Button2.Location = New System.Drawing.Point(700, 46)
        Me.Guna2Button2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Guna2Button2.Name = "Guna2Button2"
        Me.Guna2Button2.ShadowDecoration.Parent = Me.Guna2Button2
        Me.Guna2Button2.Size = New System.Drawing.Size(219, 46)
        Me.Guna2Button2.TabIndex = 12
        Me.Guna2Button2.Text = "Add Product"
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.Controls.Add(Me.lblLowStock)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.lblTotalSales)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.Chart1)
        Me.TabPage1.Controls.Add(Me.btnAddProduct)
        Me.TabPage1.Controls.Add(Me.lblTotalProd)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Location = New System.Drawing.Point(4, 5)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage1.Size = New System.Drawing.Size(1342, 982)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'lblLowStock
        '
        Me.lblLowStock.AutoSize = True
        Me.lblLowStock.BackColor = System.Drawing.Color.Red
        Me.lblLowStock.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLowStock.ForeColor = System.Drawing.Color.White
        Me.lblLowStock.Location = New System.Drawing.Point(750, 71)
        Me.lblLowStock.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLowStock.Name = "lblLowStock"
        Me.lblLowStock.Size = New System.Drawing.Size(51, 55)
        Me.lblLowStock.TabIndex = 15
        Me.lblLowStock.Text = "0"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Red
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(705, 169)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(148, 25)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "Low Stock Alert"
        '
        'lblTotalSales
        '
        Me.lblTotalSales.BackColor = System.Drawing.Color.Red
        Me.lblTotalSales.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalSales.ForeColor = System.Drawing.Color.White
        Me.lblTotalSales.Location = New System.Drawing.Point(411, 71)
        Me.lblTotalSales.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTotalSales.Name = "lblTotalSales"
        Me.lblTotalSales.Size = New System.Drawing.Size(152, 75)
        Me.lblTotalSales.TabIndex = 12
        Me.lblTotalSales.Text = "13"
        Me.lblTotalSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Red
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(429, 169)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(111, 25)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Total Sales"
        '
        'Chart1
        '
        ChartArea5.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea5)
        Legend5.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend5)
        Me.Chart1.Location = New System.Drawing.Point(48, 283)
        Me.Chart1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Chart1.Name = "Chart1"
        Series5.ChartArea = "ChartArea1"
        Series5.Legend = "Legend1"
        Series5.Name = "Series1"
        Me.Chart1.Series.Add(Series5)
        Me.Chart1.Size = New System.Drawing.Size(784, 405)
        Me.Chart1.TabIndex = 9
        Me.Chart1.Text = "Chart1"
        '
        'btnAddProduct
        '
        Me.btnAddProduct.BorderColor = System.Drawing.Color.Red
        Me.btnAddProduct.BorderRadius = 10
        Me.btnAddProduct.BorderThickness = 1
        Me.btnAddProduct.CheckedState.Parent = Me.btnAddProduct
        Me.btnAddProduct.CustomBorderColor = System.Drawing.Color.Red
        Me.btnAddProduct.CustomImages.Parent = Me.btnAddProduct
        Me.btnAddProduct.FillColor = System.Drawing.Color.White
        Me.btnAddProduct.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddProduct.ForeColor = System.Drawing.Color.Black
        Me.btnAddProduct.HoverState.Parent = Me.btnAddProduct
        Me.btnAddProduct.Location = New System.Drawing.Point(842, 297)
        Me.btnAddProduct.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnAddProduct.Name = "btnAddProduct"
        Me.btnAddProduct.ShadowDecoration.Parent = Me.btnAddProduct
        Me.btnAddProduct.Size = New System.Drawing.Size(182, 62)
        Me.btnAddProduct.TabIndex = 8
        Me.btnAddProduct.Text = "Add Product"
        '
        'lblTotalProd
        '
        Me.lblTotalProd.AutoSize = True
        Me.lblTotalProd.BackColor = System.Drawing.Color.Red
        Me.lblTotalProd.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalProd.ForeColor = System.Drawing.Color.White
        Me.lblTotalProd.Location = New System.Drawing.Point(148, 71)
        Me.lblTotalProd.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTotalProd.Name = "lblTotalProd"
        Me.lblTotalProd.Size = New System.Drawing.Size(78, 55)
        Me.lblTotalProd.TabIndex = 2
        Me.lblTotalProd.Text = "13"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Red
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(111, 169)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(138, 25)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Total Products"
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.ItemSize = New System.Drawing.Size(0, 1)
        Me.TabControl1.Location = New System.Drawing.Point(180, 0)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1350, 991)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 8
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.White
        Me.TabPage5.Controls.Add(Me.Chart2)
        Me.TabPage5.Location = New System.Drawing.Point(4, 5)
        Me.TabPage5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage5.Size = New System.Drawing.Size(1342, 982)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "TabPage5"
        '
        'Chart2
        '
        ChartArea6.Name = "ChartArea1"
        Me.Chart2.ChartAreas.Add(ChartArea6)
        Legend6.Name = "Legend1"
        Me.Chart2.Legends.Add(Legend6)
        Me.Chart2.Location = New System.Drawing.Point(84, 138)
        Me.Chart2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Chart2.Name = "Chart2"
        Series6.ChartArea = "ChartArea1"
        Series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Renko
        Series6.Legend = "Legend1"
        Series6.Name = "Series1"
        Series6.YValuesPerPoint = 4
        Me.Chart2.Series.Add(Series6)
        Me.Chart2.Size = New System.Drawing.Size(906, 462)
        Me.Chart2.TabIndex = 0
        Me.Chart2.Text = "Chart2"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.WindowsApplication1.My.Resources.Resources.Group_1
        Me.PictureBox2.Location = New System.Drawing.Point(1268, 40)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(238, 48)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 7
        Me.PictureBox2.TabStop = False
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1530, 991)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "t"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.pnlSaleschkOut.ResumeLayout(False)
        Me.pnlSaleschkOut.PerformLayout()
        CType(Me.picSales, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.pnlPayment.ResumeLayout(False)
        Me.pnlPayment.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.picSale, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.picQRBAR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picProd, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lblLogOut As System.Windows.Forms.Label
    Friend WithEvents lblReport As System.Windows.Forms.Label
    Friend WithEvents lblSales As System.Windows.Forms.Label
    Friend WithEvents lblProduct As System.Windows.Forms.Label
    Friend WithEvents lblDashboard As System.Windows.Forms.Label
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Guna2Elipse2 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Guna2Elipse3 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents picSale As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents btnUpload As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnCancel As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnAddProd As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents chkXXXL As System.Windows.Forms.CheckBox
    Friend WithEvents chkXXL As System.Windows.Forms.CheckBox
    Friend WithEvents chkXL As System.Windows.Forms.CheckBox
    Friend WithEvents chkL As System.Windows.Forms.CheckBox
    Friend WithEvents chkM As System.Windows.Forms.CheckBox
    Friend WithEvents chkS As System.Windows.Forms.CheckBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents ChkDress As System.Windows.Forms.CheckBox
    Friend WithEvents ChkPants As System.Windows.Forms.CheckBox
    Friend WithEvents ChkSweather As System.Windows.Forms.CheckBox
    Friend WithEvents ChkTshirt As System.Windows.Forms.CheckBox
    Friend WithEvents ChkPolo As System.Windows.Forms.CheckBox
    Friend WithEvents ChkHoodie As System.Windows.Forms.CheckBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtStock As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtColor As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents picProd As System.Windows.Forms.PictureBox
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape3 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape2 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents btnViewStock2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnViewStock As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Guna2Button2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents lblLowStock As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lblTotalSales As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Chart1 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents btnAddProduct As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents lblTotalProd As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents btnDelete As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents txtSName As System.Windows.Forms.Label
    Friend WithEvents btnAddSales As System.Windows.Forms.Button
    Friend WithEvents btnQrBar As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents picQRBAR As System.Windows.Forms.PictureBox
    Friend WithEvents txtPrice As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents LineShape4 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtSPrice As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnComplete As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents lblClose As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlSaleschkOut As System.Windows.Forms.Panel
    Friend WithEvents lblNum As System.Windows.Forms.Label
    Friend WithEvents lblQuantity As System.Windows.Forms.Label
    Friend WithEvents lblPlus As System.Windows.Forms.Label
    Friend WithEvents lblMinus As System.Windows.Forms.Label
    Friend WithEvents lblSPrice As System.Windows.Forms.Label
    Friend WithEvents lblSName As System.Windows.Forms.Label
    Friend WithEvents picSales As System.Windows.Forms.PictureBox
    Friend WithEvents lblRemove As System.Windows.Forms.Label
    Friend WithEvents pnlPayment As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnPayment As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lblProdName As System.Windows.Forms.Label
    Friend WithEvents lblPQuanity As System.Windows.Forms.Label
    Friend WithEvents lblTotals As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Chart2 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents lblPrice As System.Windows.Forms.Label
    Friend WithEvents txtProdName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents cmbFilter As System.Windows.Forms.ComboBox
End Class
